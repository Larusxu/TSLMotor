# TSL Viewer · TMC6460 运动控制工作台

面向 **TMC6460 + MT6701 + Tesla 灵巧手电机** 的上位机，替代厂商 `tmc6460-console` 与遗留 `tmc6460_upper_pc`（PyQt）。
技术栈：**Tauri v2（Rust）+ React 18 + TypeScript + Vite**。串口、协议、标定、测试序列全部在 Rust 侧完成，前端只负责渲染与交互。

> 配套文档（项目根目录）：`TMC6460调试软件操作手册.md`（协议 / PID / 寄存器详解）、`tsla电机调试参考.md`（Tesla 平台参数表）。
> **本软件的操作手册**：[`doc/TSLViewer操作手册.md`](./doc/TSLViewer操作手册.md)（安装、十一步上电流程、九个页面逐页说明、PID 调参与故障排查）；流程编排见 [`doc/TSLViewer流程手册.md`](./doc/TSLViewer流程手册.md)；术语原理见 [`doc/TSLViewer术语与原理手册.md`](./doc/TSLViewer术语与原理手册.md)。
> 芯片手册：`tmc6460.pdf`、MT6701 数据手册 `MT6701.pdf`。

---

## 1. 快速开始

```powershell
cd TSLViewer
npm install

npm run dev          # 仅前端（浏览器 + 内置模拟器，无需硬件）
npm run app:dev      # 完整桌面应用（Tauri 窗口，接真实串口）
npm run build        # 类型检查 + 前端产物
npm run app:build    # 生成 Windows 安装包（msi / nsis）
```

### 1.1 一键启动脚本

`scripts\start.bat` 双击即可（等价于 `.\scripts\start.ps1`）：直接运行已构建好的 `src-tauri\target\release\tslviewer.exe`，不编译、不打包、不起前端服务。

```powershell
.\scripts\start.ps1
```

程序不存在时会提示先执行 `npm run app:exe`（只构建不打包）；需要重新构建、开发模式或浏览器预览时用下面的脚本或 npm 命令。

### 1.2 构建脚本

`scripts\build.bat` 双击即可（等价于 `.\scripts\build.ps1`）：检查工具链 → 检查是否有 TSL Viewer 正在运行（会锁住 exe）→ 构建 → 报告产物与耗时，全部输出同时落盘到 `build-logs\build-<时间戳>.log`。

```powershell
.\scripts\build.ps1                # 只构建 exe（tauri build --no-bundle），不打包
.\scripts\build.ps1 -Test          # 先跑 cargo test --lib，通过才构建
.\scripts\build.ps1 -Clean         # 先删 dist\ 与 release 产物再构建
.\scripts\build.ps1 -StopRunning   # 自动关闭正在运行的 TSL Viewer（否则链接会失败）
.\scripts\build.ps1 -Launch        # 构建完直接启动
.\scripts\build.ps1 -Bundle        # 额外生成 NSIS 安装包（发版用）
```

| 选项 | 作用 |
| --- | --- |
| 默认 | `npm run app:exe`：tsc 类型检查 + vite + cargo release，**只出 exe** |
| `-Bundle` | 改跑 `npm run app:build`，额外产出 `bundle\nsis\TSL Viewer_<版本>_x64-setup.exe` |
| `-Test` | 编译前跑 Rust 单测，失败立即终止，不会产出半新半旧的 exe |
| `-Clean` | 删 `dist\`、`release\tslviewer.exe`、`bundle\`；**不跑 `cargo clean`**（那会连依赖一起删，下次要重编十几分钟） |
| `-StopRunning` | 结束正在运行的 `tslviewer.exe`；不加则检测到就报错退出，不会偷偷关掉你正在看的窗口 |
| `-Launch` | 成功后直接启动新程序 |

退出码：0 = 成功，非 0 = 失败（`build.bat` 会 `pause` 留住报错）。

产物位置：

| 产物 | 路径 |
| --- | --- |
| 可执行文件 | `src-tauri/target/release/tslviewer.exe` |
| 安装包 | `src-tauri/target/release/bundle/` |
| 前端静态产物 | `dist/` |

**浏览器模拟模式**：直接 `npm run dev` 打开页面时，检测不到 Tauri 运行时，`src/lib/api.ts` 会切到内置模拟器（虚拟 COM6、CHIP.ID = 0x64600001、正弦转速/电流、可跑完对齐与测试序列）。用于看界面、演示、录屏，**不产生任何串口流量**。侧栏底部"构建 = preview"即为模拟模式。

### 1.2 无硬件：桌面版内置模拟器 `SIM1`

没有板子也能用完整桌面应用：端口下拉的**第一项固定是 `SIM1`（内置模拟器 · 无需硬件）**，选中并连接即可，串口号与波特率随意（模拟器不校验波特率）。

模拟器独立成工程 [`TSLMotor/TSLmoni`](../TSLmoni/README.md)（零依赖 Rust crate + 可独立运行的 CLI），桌面端通过 path 依赖引入，`src-tauri/src/simport.rs` 只做一层 `gateway::Wire` 适配——网关帧（RS485 Modbus-RTU / USB-CAN-A）、TMC 数据报、所有 procs 与 RTMI 走的都是**真实代码路径**。行为对齐 `TSLHand` 固件：

| 项 | 模拟行为 |
| --- | --- |
| 主控协议 | `moto/los_moto.c` 的 op 码（WRITE/READ/CLEAR/INFO/POWER/ALL_OFF/KEEPALIVE/OPEN/CLOSE/BOARD/HAND_ID）与错误码（OK/BAD/NOT_READY/IO/OVERFLOW/BUSY） |
| 节点/N 路 | 16 个 TMC6460 节点，路由表同 `Modbus/los_motor_routes.c`（uart / chip / output / sys / connector），`CHIP.ID = 0x64600001` |
| 占用与租约 | `MOTO_OPEN` 抢占 owner，5 s 无请求自动 `ALL_OFF`；他人访问返回 `MOTO_BUSY` |
| 板级快照 | `MOTO_BOARD(start,count)`：`0x08` 起 16 字符固件串 `TSL-SIM FWHOST01`，word 73 为 HandID（可在界面改 HandID 后回读） |
| 电源 | 4 片 MAX20087 的掩码，`MOTO_INFO` 回读 `config = 16|mask` 与 `diagnostics_live` |
| RX 缓冲 | 每节点 2048 B 环形缓冲，溢出后 `MOTO_READ` 返回 `MOTO_OVERFLOW`，需 `MOTO_CLEAR` |
| 电机侧 | 10-bit 寄存器全量读写；速度/位置/力矩模式有简单动力学（位置/速度/电流回读会动），RTMI 帧按 `UART.CONTROL` 采样率与 `RTMI_CH_x` 映射合成 |

注意：模拟器**不做真实 FOC 与电流环物理响应**，阶跃/PID 辨识看到的是合成波形；寄存器读写、电源时序、协议时序与固件一致。

独立使用（不启动上位机）时：

```powershell
cd TSLMotor\TSLmoni
cargo run --release --bin tslmoni -- --selftest    # 协议自检
cargo run --release --bin tslmoni -- --rpc         # 十六进制报文服务器（stdin/stdout）
```

---

## 2. 页面一览

| 页面 | 代号 | 作用 |
| --- | --- | --- |
| 运行概览 | RUN | KPI（实际/目标转速、iQ、结温）+ 实时示波器 + 手动运行 |
| 编码器与对齐 | SSI | MT6701 SSI 帧参数、CPR/极对数、角度回读、写入校验；第二节做 φ_e 电角度对齐（4 点拟合）与闭环速度试转 |
| 机械找零 | HOME | 撞限位建立行程零点：上位机只下发方向/步进并显示主控状态 |
| 机械行程 | AXIS | 丝杆导程换算、软限位保护、点动/定位、回零向导 |
| PID 与限幅 | TUNE | 电流/速度/位置三环系数、归一化、限幅、阶跃响应一键辨识 |
| 环路测试 | LOOP | 受保护行程内的恒 Iq / 恒速度探测、速度 PI 自动辨识、位置环跟随测试与波形 |
| 寄存器 | MAP | 189 个寄存器浏览、位编辑、写读校验、常用快照 |
| 自动测试 | QA | 多档位转速序列、判据容差、CSV 报告 |
| 运行日志 | LOG | 全链路日志、级别过滤、关键字检索、复制导出 |

### 2.1 运行概览
- 三个 KPI 为 **RTMI 实时值**（未开采集时显示寄存器直读值）。
- 示波器：右上选择窗口（2/5/15/60 s），通道下拉可把 CH0–CH6 映射到任意观测量；`暂停` 冻结画面，`停止` 释放 RTMI。
- 底部状态行显示实测帧率、RTMI 采样参数与丢弃字节数——**丢字节不为 0 就先降采样率或提高波特率**。
- 右侧提示的带宽估算（115200 × 4 通道 ≈ 1.7 ms）来自实测，不是经验值。

### 2.2 编码器（MT6701）
- 预设 `MT6701 · SSI 14-bit（台架已验证）` 与遗留台架一致：`SPI_MODE=模式1`、`SCK=2 MHz`、`half=14`（半周期 14 个 fPLL 周期）、`idle=16`、`mask=0x3FFF`、`CPR=16384`、`CPR_INV=1024`。
- 24-bit SSI 原始帧（D[13:0]+Mg[3:0]+CRC[6:1]）会整段落入 `PHI_EXT_A[23:0]`，此时 `CPR_INV` 要按 2²⁴/CPR 换算（16 384 CPR → 1024 仍需按 14-bit 对齐方式取高位），页内"预期 vs 实测"表会直接告诉你帧是否对。
- 极对数 1（`PHI_E_MUL_FACTOR=1`）。**这是 Tesla 电机的实测值**，换电机必须重新确认。
- 写入前需勾选确认项，因为 `IO_MATRIX / IO_CTRL / FEEDBACK` 会立即改变引脚行为。

### 2.3 电角度对齐与闭环（编码器与对齐页第二节）
- 开环电流拖动电角度，步进 90° 扫描 2 个电周期，取 4 点做拟合，回写 `0x242`。
- 对齐电流默认 300 mA（Tesla 电机限幅仅 800 mA，**不要用厂商默认 10 000 counts ≈ 2 A**）。
- 闭环试转必须先 ARM；飞车时顶栏 `急停` 会立刻写 0 目标、PWM_OFF、清 DRV_EN。

### 2.4 机械行程（丝杆 / 软限位）
电机装上丝杆后就有了不能撞的机械死点，这一页是软件层的最后一道闸。

- **换算**：输入丝杆导程（mm/转）、有效行程、远端安全边距，页内自动把 mm 折算成编码器 counts（每毫米 = CPR×4 / 导程，Tesla 平台 2 mm 导程 → 32768 counts/mm）。
- **窗口语义**：近端就是机械原点（归零后停的位置，不能把自己关在门外），安全边距从**远端**扣掉，画成橙色斜纹区。
- **强制前置条件**：`写入软限位` 会先检查位置反馈是否在跑——先点「接入位置反馈 0x155」，让某个 RTMI 通道采 `实际位置`，否则直接报错。开保护却没有反馈，等于没有保护。
- **生效点**：Rust 的 RTMI 线程**每收到一帧位置**就比对一次（1 kHz 级），越界立刻写 0 目标并清积分器；`越限动作 = 刹车` 时改为 PWM_OFF + 清 DRV_EN。
- **多圈展开**：`0x155` 是 32 位多圈计数器，本身不每圈归零；软件取样时只留低 16 位（兼容只转发 16 位的主控板链路），再把相邻帧差值累加回连续位置（相邻两帧不会超过半圈），限位与显示都用展开后的值。
- **受控运动**：点动 ±（速度可调）、按 mm 定位（梯形速度曲线，`v = min(v_max, √(2·a·Δ))`，永远来得及刹车）、5 个预设位。所有运动都要 ARM + 勾选确认，越界目标在下发前就被拒绝。
- **回零**：正式流程是**主控固件**执行的「撞限位找零」（电流判据 + 连续确认 + 退开），上位机只在「机械找零」页下发方向与步进、显示状态；固件尚未支持时可用本页手动兜底：① 临时关软限位 → ② 低速缩回顶住机械限位 → ③ 停止 → ④ 「设为原点」 → ⑤ 重新写入软限位。

### 2.5 PID 与限幅
- 三环系数按 Q 格式归一化：电流环默认 `Shift by 8 / Q8.8`（与 `0x855C` 出厂默认一致），速度/位置环可切 Q0.16。
- 卡片内实时显示换算后的 `Kp / Ki`，**避免把寄存器整数当成增益**（电流环归一化选错一位就是 256 倍误差）。
- `从芯片读取` 一次性抓回 `0x142/0x143/0x145/0x146/0x140/0x855C` 与限幅，用于对照遗留参数。
- 阶跃响应：给定目标 → 采 RTMI → 自动算上升时间、超调、稳态误差，并给出建议 PI（`suggest_pi` 用 R/L 与带宽反算）。
- 限幅：力矩 `800 mA`（Tesla 实机）、速度 `25 000 RPM`、`UQ/UD` 合成限幅 `0x5A81`。

### 2.5b 环路测试
- 定位：在**受保护行程内**验证闭环特性，开发/验证/排障用，不参与生产；必须先在「机械找零」建好零点。
- 分工：**闭环与限幅全在 TMC6460**，上位机只做四件事——写模式/给定/限幅、每 60 ms 读 `0x155` 判边界、换 `0x145` 打分选优、采样画波形。不加任何新协议。
- ①恒 Iq / 恒速度：`MOTION_MODE = TORQUE / VELOCITY`，电流上限写 `0x14A[30:16]`（**力矩模式同样生效**），行程按整程 8 等分选区间，边界策略「停止 / 自动换向」。
- ②速度 PI 自动辨识：逐组写 `0x145`、给 ±转速，饱和样本整组判废，`J = errRMS + 0.35·|errMean| + 0.20·σ(i_q)` 选优，可选「完成后应用最佳」。
- ③位置环测试：保持 / A/B 往复 / 正弦，固定位置直通（`RAMP_EN=0`，目标直接写 `0x152`），先写首目标再使能 → 起步冲击是故意的；另写 `0x14C/0x14D` 作芯片级护栏。
- 实时值 / 波形：60 ms 一拍，历史 900 点；看不到 25 kHz 电流环尺度（那是 RTMI 抓 `0x153/0x168` 的活）。
- 固件侧要求见 [`doc/TODO/TODO-02-环路测试.md`](./doc/TODO/TODO-02-环路测试.md)：模式仲裁、不覆盖限幅/增益、故障清目标、`0x14C/0x14D` 默认值等 8 条。

### 2.6 寄存器
- 左侧 189 项可按名称/地址/中文标签搜索，`常用` 只留关键项。
- 右侧可位编辑：点任意 bit 翻转，位域表和二进制串同步；写入后默认回读校验。
- 只读寄存器（`CHIP.ID`、`STATUS_FLAGS` 等）会在写入时被拦住。

### 2.7 自动测试
- 档位表（转速/保持时间）→ 逐档闭环运行 → 采窗口数据 → 判据（容差 %）→ 生成 CSV。
- 序列号必填，用于文件名与追溯；报告落在 `文档\TSLViewer\reports`（`open_reports_dir` 直接打开）。
- 必须勾选安全确认并 ARM，"开始测试"才可用。

---

## 3. 硬件与参数速查（Tesla 平台）

| 项 | 值 | 来源 |
| --- | --- | --- |
| 极对数 | 1 | 固件 / 遗留上位机 / 实测波形 |
| 编码器线数 CPR | 16384 | `motor_config.h` |
| PWM 频率 | 25 kHz（MAX_COUNT 4800 @ 120 MHz） | 寄存器回读 |
| 电流分辨率 | 0.20131 mA/LSB（CSA ×4，55 mΩ） | 数据手册公式 |
| 满量程 | 8192 LSB = 1.65 A | 同上 |
| 转速换算 | 305.4 counts / RPM | 65536 / 214.6 |
| 位置换算 | 65536 counts / 圈 | CPR × 4 |
| 丝杆每毫米计数 | 32768 counts/mm | 65536 / 导程 2 mm |

详细推导见根目录 `tsla电机调试参考.md` 第 4–6 章。

---

## 4. 通信与协议实现要点

代码：`src-tauri/src/proto.rs`（含 5 个单元测试，用例取自手册示例）、`link.rs`。

| 报文 | 字节 | 说明 |
| --- | --- | --- |
| 读请求 | 2 | `0x42 \| addr[9:8]<<4`, `addr[7:0]` |
| 读响应 | 6 | byte2..5 = 大端 u32；同步判定 `(b&0x07)==0x02 && (b&0xC0)==0x40` |
| 写请求 | 6 | `0x4A \| addr[9:8]<<4`, `addr[7:0]`, 大端 u32 |
| 写响应 | 7 | **仅当 `UART.RTMI_CH_7.CH_7_EN=1` 才回**；因此本应用一律用"写后回读"确认 |
| RTMI 帧 | 5(+1 CRC) | `bit0=1`、`bit7=0`、`bits[3:1]=通道`、`bits[6:4]=写入计数` |
| RTMI 触发率 | — | `fPWM / (RTMI_SAMPLING + 1)` |

- `UART.CONTROL` 复位值 `0x00040000`（含 `AUTOBAUD_EN`），任何改动都走"读-改-写"，绝整字覆盖。
- 写事务期间 RTMI 线程会被 `paused` 原子量挂起，避免读到回环报文；这就是日志里偶发"暂停 1 帧"的原因。
- CRC-8（多项式 0x1D，输入反射）已实现但默认关闭，与厂商工具保持一致。

---

## 5. 安全设计

1. **ARM 门禁**：所有会动车的动作（对齐、闭环试转、序列、点动、定位）都要求先点 `ARM`。
2. **行程保护**：装上丝杆后必须开启软限位。开启前强制校验位置反馈已启动；越界在下发前拒绝、运行中每帧复检、触发后拒绝后续运动直到复位。
3. **急停**：顶栏红色按钮写入 0 目标 → `PWM_OFF` → 清 `DRV_EN`，并置位取消标志终止正在跑的任务。
4. **二次确认**：写编码器配置、跑序列、闭环试转、点动/定位都有勾选项，防止误点。
5. **任务互斥**：全局 `busy` 标志，同一时刻只允许一个长任务；`cancel_job` 可中断。
6. **写后回读**：所有关键写入都回读校验，不一致会在日志里标 `warn`。
7. **反馈中断即拒动**：保护开启但 RTMI 停了，`axis_jog` / `axis_move` 直接返回错误——宁可不走，也不盲走。

---

## 6. 目录结构

```
TSLViewer/
├─ src/                       前端
│  ├─ pages/                  8 个页面
│  ├─ components/             ui 原语、Scope 画布示波器、Sidebar、TopBar
│  ├─ lib/                    api（真实+模拟）、scope 环形缓冲、store、寄存器表、单位换算
│  └─ styles/                 设计令牌 + 应用样式
├─ src-tauri/
│  ├─ src/proto.rs            帧解析 / 组包 / CRC（含单测）
│  ├─ src/regs.rs             地址与位域辅助
│  ├─ src/axis.rs             丝杆软限位：多圈展开、越界检测、梯形定位
│  ├─ src/link.rs             串口、事务、RTMI 线程、记录器、急停、保护联动
│  ├─ src/procs.rs            编码器向导、φ_e 标定、PID 下发、阶跃、序列
│  ├─ src/lib.rs              Tauri 命令与任务调度
│  └─ tauri.conf.json         窗口默认 1440×900，最小 1120×700；启动时按显示器自动收敛
├─ scripts/
│  ├─ build.ps1 / build.bat   构建：默认只出 exe，-Bundle 才打安装包
│  ├─ start.ps1 / start.bat   一键启动：直接运行已构建的 tslviewer.exe
│  ├─ start-web.ps1 / .bat    浏览器预览（vite dev server）
│  └─ test_gateway_ui.py      UI 回归（需 Vite 已启动 + Playwright + Edge）
├─ build-logs/                构建日志（gitignored）
└─ dist/                      构建产物
```

操作手册在 [`doc/TSLViewer操作手册.md`](./doc/TSLViewer操作手册.md)。

`doc/` 下三份文档分工：

| 文档 | 回答 |
|---|---|
| [TSLViewer操作手册.md](./doc/TSLViewer操作手册.md) | 这个字段填什么、这个按钮干什么 |
| [TSLViewer流程手册.md](./doc/TSLViewer流程手册.md) | 先做什么后做什么、做完怎么算过、没过怎么办 |
| [TSLViewer术语与原理手册.md](./doc/TSLViewer术语与原理手册.md) | 阶跃/软限位/Q 格式等词是什么意思、为什么这么做 |

---

## 7. 已知限制

- 未在真机上验证：本仓库所有"实测"数值来自遗留台架记录与手册公式，协议层由单测保证，**但首次上电仍需按 `TMC6460调试软件操作手册.md` 第 9 章流程走一遍**。
- 软限位是**软件层**保护：它靠位置反馈工作，反馈断了就不保护（此时会拒绝运动）。**机械限位开关与丝杆机械死点仍然必须保留**，软件限位不能替代硬件安全回路。
- MT6701 的 24-bit CRC 只做校验显示，不做纠错；报警位 `Mg[3:0]` 已在编码器页展示但未参与故障矩阵。
- 电流环自整定只输出建议 PI，不自动闭环辨识 R/L（芯片无内置阻抗测量功能）。
- 温度读数需外部校准（`0x009` 原始值为 0 表示 NTC 未接）。

## TeslaHand 主控接入（2026-10-30）

现在可选择直连电机板、主控 RS485、主控 USB-CAN-A 三种模式，以及 M1～M16。
「TeslaHand 主控」卡在运行概览页最底部：固件版本、16 路映射（双栏 M1–M8 / M9–M16，列为主控 UART、逻辑供电、TMC 在线）、逻辑上电/断电与全部断电。
顶栏电机下拉移到 ARM 右侧并可在连接状态下直接切换，旁边的使能按钮一点即上电并读 `CHIP.ID`：成功变绿「已使能」，失败保持红「未使能」。
原有操作走选中电机通道，RTMI 在网关模式按2000 B/s预算限流；这不等于16路同时高速采集或实板运动验收。
详见 [TeslaHand主控连接模式](doc/TeslaHand主控连接模式.md)。
