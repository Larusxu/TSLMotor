﻿export { default } from "./SplitStorage";
