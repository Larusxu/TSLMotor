import { useEffect, useRef, useState } from "react";
import { api, invokeCommand } from "./api";
import type { MotorState, SemanticReply } from "./semantic-state";
import { acquisitionLane } from "./pi-auto/acquisition";

export interface FleetMotor { state: MotorState | null; at: number; sampleAt: number; error: string }
export interface PowerOutput { enabled: boolean | null; fault: string; live: boolean }
export function words(bytes: number[], count: number) {
  if (bytes.length !== count * 2) throw Error("主控快照长度错误");
  return Array.from({ length: count }, (_, i) => bytes[i * 2] * 256 + bytes[i * 2 + 1]);
}
export function decodePower(chips: number[], motors: number[]): PowerOutput[] {
  if (chips.length !== 32 || motors.length !== 128) throw Error("供电快照不完整");
  return Array.from({ length: 16 }, (_, i) => {
    const row = motors.slice(i * 8, i * 8 + 8), base = row[1] * 8, output = row[2] - 1;
    if (base > 24 || output < 0 || output > 3 || !row[6] || !chips[base])
      return { enabled: null, fault: "", live: false };
    const common = chips[base + 4] & 0x2f;
    const channel = (chips[base + 5 + Math.floor(output / 2)] >>> (4 * (output % 2))) & 15;
    const faults: string[] = [];
    if (common & 32) faults.push("限流设置异常");
    if (common & 8) faults.push("输入过压");
    if (common & 4) faults.push("输入欠压");
    if (common & 2) faults.push("逻辑电源过压");
    if (common & 1) faults.push("逻辑电源欠压");
    if (channel & 8) faults.push("输出过温");
    if (channel & 4) faults.push("输出过流");
    if (channel & 2) faults.push("输出过压");
    if (channel & 1) faults.push("输出欠压");
    return { enabled: row[5] === 0xffff ? null : row[5] === 1,
      fault: faults.join(" / "),
      live: !!chips[base + 3] };
  });
}

/** Read MCU snapshots only: never focus a UART, claim a session or probe a TMC. */
export function useFleet(connected: boolean, mode: string, streaming: boolean) {
  const streamingRef = useRef(streaming); streamingRef.current = streaming;
  const [motors, setMotors] = useState<Record<number, FleetMotor>>({});
  const [power, setPower] = useState<PowerOutput[]>([]);
  const [powerAt, setPowerAt] = useState(0);
  const [firmware, setFirmware] = useState("");
  const [bootId, setBootId] = useState("");
  useEffect(() => {
    setMotors({}); setPower([]); setPowerAt(0); setFirmware(""); setBootId("");
    if (!connected || mode === "direct") return;
    let alive = true, pending = false, motor = 1, sequence = 0, boot = "", nextPower = 0, versionRead = false;
    const poll = async () => {
      if (!alive || pending || acquisitionLane.busy() || streamingRef.current) return;
      pending = true;
      try {
        const reply = await invokeCommand<SemanticReply>("motor_semantic", { motor, request: {
          request_id: ++sequence, boot_id: "0", session_id: 0, task_id: 0, command: { kind: "get_state" },
        } });
        if (!alive) return;
        if (reply.result || !reply.motor) throw Error(reply.result_name);
        if (boot && boot !== reply.boot_id) { setMotors({}); setPower([]); setPowerAt(0); versionRead = false; }
        boot = reply.boot_id; setBootId(boot);
        const id = motor;
        const sampleAt = Date.now() - ((reply.timestamp_ms - reply.motor.sampled_at_ms) >>> 0);
        setMotors(old => ({ ...old, [id]: { state: reply.motor, at: Date.now(), sampleAt, error: "" } }));
        motor = motor % 16 + 1;
        if (Date.now() >= nextPower && !acquisitionLane.busy()) {
          nextPower = Date.now() + 3000;
          const chips = words(await api.mainControl(0, 10, [80, 32]), 32);
          if (!alive || acquisitionLane.busy()) return;
          const first = words(await api.mainControl(0, 10, [128, 64]), 64);
          if (!alive || acquisitionLane.busy()) return;
          const last = words(await api.mainControl(0, 10, [192, 64]), 64);
          if (!alive) return;
          setPower(decodePower(chips, [...first, ...last])); setPowerAt(Date.now());
        }
        if (!versionRead && !acquisitionLane.busy()) {
          const data = await api.mainControl(0, 10, [8, 32]);
          if (alive) setFirmware(String.fromCharCode(...data).replace(/\0/g, " ").trim());
          versionRead = true;
        }
      } catch (e) {
        const id = motor;
        if (alive) setMotors(old => ({ ...old, [id]: { state: old[id]?.state ?? null, at: old[id]?.at ?? 0, sampleAt: old[id]?.sampleAt ?? 0, error: String(e) } }));
        motor = motor % 16 + 1;
      } finally { pending = false; }
    };
    void poll(); const timer = setInterval(() => void poll(), 200);
    return () => { alive = false; clearInterval(timer); };
  }, [connected, mode]);
  return { motors, power, powerAt, firmware, bootId };
}
