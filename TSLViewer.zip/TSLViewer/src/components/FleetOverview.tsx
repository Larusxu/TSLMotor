import { useEffect, useState } from "react";
import { useApp } from "../lib/app-store";
import { tempC, fmt } from "../lib/units";
import { Badge, Card } from "./ui";

const modes = ["位置直通", "位置插补", "速度直通", "速度斜坡"];
export default function FleetOverview() {
  const app = useApp(), { motors, power, powerAt, firmware } = app.fleet;
  const [now, setNow] = useState(Date.now());
  useEffect(() => { const t = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(t); }, []);
  const paused = app.acquiring || app.streaming;
  const fresh = (n: number) => app.connected && !!motors[n]?.at && now - motors[n].at < 8000;
  const online = Object.entries(motors).filter(([id, v]) => fresh(+id) && v.state?.logic_power && v.state.config_verified && now - v.sampleAt < 5000).length;
  const faults = Object.values(motors).filter(v => v.state?.fault).length;
  return <section className="fleet" aria-label="16 路电机概览">
    <div className="fleet-summary">
      <div><span>主控</span><strong>{app.connected ? "已连接" : "未连接"}</strong><small>{app.port} · 1.5 Mbps</small></div>
      <div><span>固件版本</span><strong className="fleet-version">{firmware || "—"}</strong><small>主控只读快照</small></div>
      <div><span>在线电机</span><strong>{online}<em> / 16</em></strong><small>{paused ? "采集优先 · 概览暂停刷新" : "逐路更新"}</small></div>
      <div><span>设备告警</span><strong className={faults ? "fleet-danger" : ""}>{faults}<em> 路</em></strong><small>未读取的设备不计为正常</small></div>
    </div>
    <Card title="电机阵列" right={<Badge tone={paused ? "warn" : "neutral"}>{paused ? "显示最近快照" : "16 CHANNELS"}</Badge>}>
      <div className="fleet-grid">
        {Array.from({ length: 16 }, (_, i) => {
          const id = i + 1, entry = motors[id], s = entry?.state, live = fresh(id), p = power[i];
          const powered = !!powerAt && now - powerAt < 8000 && app.connected;
          const online = live && !!s?.logic_power && !!s.config_verified && now - entry.sampleAt < 5000;
          const powerLabel = !powered || !p || p.enabled === null ? "供电未知" : p.fault ? p.fault : p.enabled ? "输出已使能" : "输出未使能";
          const powerTone = !powered || !p || p.enabled === null ? "unknown" : p.fault || !p.enabled ? "bad" : "good";
          return <button type="button" key={id} className={`fleet-motor ${app.motor === id ? "selected" : ""}`}
            aria-pressed={app.motor === id} aria-label={`选择电机 M${id}`}
            disabled={app.busy || app.jobRunning || app.motionActive || app.acquiring}
            onClick={() => app.setMotor(id)}>
            <div className="fleet-motor-head"><strong>M{String(id).padStart(2, "0")}</strong><span className={online ? "fleet-good" : live ? "fleet-danger" : "muted"}>TMC · {online ? "在线" : live ? "掉线" : "未确认"}</span></div>
            <div className={`fleet-power ${powerTone}`}><i aria-hidden="true"/>{powerLabel}</div>
            <div className="fleet-metrics"><div><span>温度</span><b>{live && online && s?.temperature_raw != null ? fmt(tempC(s.temperature_raw * 65536, app.cal.tempOffset), 1) : "—"}<small> °C</small></b></div><div><span>力矩电流</span><b>{online && s ? fmt(s.iq_raw * app.cal.maPerCount, 0) : "—"}<small> mA</small></b></div></div>
            <dl><div><dt>编码器</dt><dd>{!live ? "未确认" : s?.align_valid ? "有效" : "待标定"}</dd></div><div><dt>找零</dt><dd>{!live ? "未确认" : s?.span_valid ? "有效" : "待找零"}</dd></div><div><dt>运动模式</dt><dd>{live && s ? modes[s.mode] ?? "未知" : "—"}</dd></div></dl>
            <footer><span>{live && s ? s.fault ? `故障 ${s.fault}` : s.motion_active ? "运行中" : s.config_verified ? "就绪" : "待初始化" : "等待状态"}</span><span>{entry?.at ? `${Math.max(0, Math.floor((now-entry.at)/1000))} 秒前` : "尚未更新"}</span></footer>
          </button>;
        })}
      </div>
    </Card>
  </section>;
}
