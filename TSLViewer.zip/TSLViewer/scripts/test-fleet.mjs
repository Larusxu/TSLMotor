import fs from 'node:fs';
import ts from 'typescript';
import assert from 'node:assert/strict';
const url = code => 'data:text/javascript;base64,' + Buffer.from(code).toString('base64');
let code = ts.transpileModule(fs.readFileSync(new URL('../src/lib/fleet.ts', import.meta.url), 'utf8'), {
  compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ES2022 },
}).outputText;
const stubs = {
  react: 'export const useEffect=()=>{},useState=()=>{},useRef=()=>{};',
  './api': 'export const api={},invokeCommand=()=>{throw Error("offline test must not contact hardware")};',
  './pi-auto/acquisition': 'export const acquisitionLane={busy:()=>false};',
};
code = code.replace(/from ["']([^"']+)["']/g, (_, name) => 'from ' + JSON.stringify(url(stubs[name])));
const { decodePower, words } = await import(url(code));
assert.deepEqual(words([0x12, 0x34, 0xff, 0xff], 2), [0x1234, 0xffff]);
assert.throws(() => words([1], 1));
const chips = Array(32).fill(0), motors = Array(128).fill(0);
for (let i = 0; i < 4; i++) { chips[i * 8] = 1; chips[i * 8 + 3] = 1; }
// Deliberately non-linear mapping: UI must use the MCU's route, not M / 4.
for (let i = 0; i < 16; i++) {
  motors[i * 8 + 1] = 3 - Math.floor(i / 4);
  motors[i * 8 + 2] = 4 - i % 4;
  motors[i * 8 + 5] = 1; motors[i * 8 + 6] = 1;
}
assert(decodePower(chips, motors).every(v => v.enabled && !v.fault && v.live));
// STAT1.ACC is conversion completion, not a fault.
chips[4] = 0x10;
assert(decodePower(chips, motors).every(v => !v.fault));
// Each STAT2 nibble belongs exclusively to one output.
for (let c = 0; c < 4; c++) for (let output = 0; output < 4; output++) {
  const at = c * 8 + 5 + Math.floor(output / 2);
  chips[at] = 4 << (4 * (output % 2));
  const result = decodePower(chips, motors);
  assert.equal(result.filter(v => v.fault).length, 1);
  assert(result[(3 - c) * 4 + 3 - output].fault.includes('过流'));
  chips[at] = 0;
}
chips[4] = 4;
assert.equal(decodePower(chips, motors).filter(v => v.fault).length, 4);
chips[4] = 0; motors[5] = 0xffff;
assert.equal(decodePower(chips, motors)[0].enabled, null);
motors[6] = 0;
assert.equal(decodePower(chips, motors)[0].live, false);
assert.throws(() => decodePower([], []));
console.log('PASS 16 non-linear routes, all STAT2 output fields, shared faults, ACC exclusion and unknown/stale power');
