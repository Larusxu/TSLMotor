platform/drivers/gt9xx/gt9xx.o: ../platform/drivers/gt9xx/gt9xx.c \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/rtdevice.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtthread.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176/rtconfig.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include\kconfig\rk3506/kconfig.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtdef.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtsched.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rttypes.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtcompiler.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rttypes.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kerrno.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/kpi.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtservice.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtm.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtatomic.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rthw.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtklibc.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kstring.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kstdio.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kerrno.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\finsh/finsh.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\finsh/finsh_service.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/classes/block.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/classes/char.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/classes/graphic.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/classes/mtd.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/classes/net.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/core/bus.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/core/driver.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/ipc/completion.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/ipc/condvar.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/ipc/dataqueue.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/ipc/pipe.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/ipc/condvar.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/ipc/poll.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/ipc/ringblk_buf.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/ipc/ringbuffer.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/ipc/waitqueue.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/ipc/workqueue.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/ipc/completion.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/ioctl.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/core/dm.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include\libadt\bitmap/bitmap.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/byteorder.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/core/master_id.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/misc.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/io.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/platform.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/core/device.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/ofw.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/libfdt/libfdt.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/libfdt/libfdt_env.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/libfdt/fdt.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include\libadt\ref/ref.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/ofw.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/ofw_io.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/ofw_irq.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/pic.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/core/dm.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/dev_rtc.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\compilers\common\include/sys/time.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\compilers\common\include/sys/signal.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\compilers\common\include/sys/time.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/dev_spi.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\gpio/gpio_dev.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/ioctl.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/dev_serial.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/dev_i2c.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/dev_watchdog.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/adc.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/dac.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/dev_pwm.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/clk.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/mtd_nand.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/can_v2.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/hwtimer.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/dev_touch.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/syscon.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\platform\drivers\gt9xx/gt9xx.h
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/rtdevice.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtthread.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176/rtconfig.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include\kconfig\rk3506/kconfig.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtdef.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtsched.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rttypes.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtcompiler.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rttypes.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kerrno.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/kpi.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtservice.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtm.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtatomic.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rthw.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtklibc.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kstring.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kstdio.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kerrno.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\finsh/finsh.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\finsh/finsh_service.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/classes/block.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/classes/char.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/classes/graphic.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/classes/mtd.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/classes/net.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/core/bus.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/core/driver.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/ipc/completion.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/ipc/condvar.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/ipc/dataqueue.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/ipc/pipe.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/ipc/condvar.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/ipc/poll.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/ipc/ringblk_buf.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/ipc/ringbuffer.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/ipc/waitqueue.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/ipc/workqueue.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/ipc/completion.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/ioctl.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/core/dm.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include\libadt\bitmap/bitmap.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/byteorder.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/core/master_id.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/misc.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/io.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/platform.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/core/device.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/ofw.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/libfdt/libfdt.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/libfdt/libfdt_env.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/libfdt/fdt.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include\libadt\ref/ref.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/ofw.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/ofw_io.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/ofw_irq.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/pic.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/core/dm.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/dev_rtc.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\compilers\common\include/sys/time.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\compilers\common\include/sys/signal.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\compilers\common\include/sys/time.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/dev_spi.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\gpio/gpio_dev.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/ioctl.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/dev_serial.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/dev_i2c.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/dev_watchdog.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/adc.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/dac.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/dev_pwm.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/clk.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/mtd_nand.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/can_v2.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/hwtimer.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/dev_touch.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include/drivers/syscon.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\platform\drivers\gt9xx/gt9xx.h:
