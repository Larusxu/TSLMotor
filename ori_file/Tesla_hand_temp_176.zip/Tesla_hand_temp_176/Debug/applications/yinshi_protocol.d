applications/yinshi_protocol.o: ../applications/yinshi_protocol.c \
 ../applications/yinshi_protocol.h
../applications/yinshi_protocol.h:
