applications/tmc6460_protocol.o: ../applications/tmc6460_protocol.c \
 ../applications/tmc6460_protocol.h
../applications/tmc6460_protocol.h:
