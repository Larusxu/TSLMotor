rt-thread/components/debug/perfetto/perfetto-server.o: \
 ../rt-thread/components/debug/perfetto/perfetto-server.c \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\perfetto/perfetto-server.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtthread.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176/rtconfig.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include\kconfig\rk3506/kconfig.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtdef.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtsched.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rttypes.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtcompiler.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rttypes.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kerrno.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/kpi.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtservice.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtm.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtatomic.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rthw.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtklibc.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kstring.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kstdio.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kerrno.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\finsh/finsh.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\finsh/finsh_service.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/service.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\net_apps\webnet\inc/webnet.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\compilers\common\include/unistd.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\compilers\common\include/sys/unistd.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\net_apps\webnet\inc/wn_module.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\net_apps\webnet\inc/wn_session.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\compilers\common\include/sys/select.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\compilers\common\include/sys/time.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\compilers\common\include/sys/signal.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\compilers\common\include/sys/time.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\net_apps\webnet\inc/wn_request.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\sal\include\socket\sys_socket/sys/socket.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\sal\include/sal_socket.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\netdev\include/arpa/inet.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\netdev\include/netdev_ipaddr.h
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\perfetto/perfetto-server.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtthread.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176/rtconfig.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include\kconfig\rk3506/kconfig.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtdef.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtsched.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rttypes.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtcompiler.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rttypes.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kerrno.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/kpi.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtservice.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtm.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtatomic.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rthw.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtklibc.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kstring.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kstdio.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kerrno.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\finsh/finsh.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\finsh/finsh_service.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/service.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\net_apps\webnet\inc/webnet.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\compilers\common\include/unistd.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\compilers\common\include/sys/unistd.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\net_apps\webnet\inc/wn_module.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\net_apps\webnet\inc/wn_session.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\compilers\common\include/sys/select.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\compilers\common\include/sys/time.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\compilers\common\include/sys/signal.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\compilers\common\include/sys/time.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\net_apps\webnet\inc/wn_request.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\sal\include\socket\sys_socket/sys/socket.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\sal\include/sal_socket.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\netdev\include/arpa/inet.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\netdev\include/netdev_ipaddr.h:
