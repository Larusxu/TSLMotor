################################################################################
# 自动生成的文件。不要编辑！
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../rt-thread/components/graphics/lvgl/src/core/lv_group.c \
../rt-thread/components/graphics/lvgl/src/core/lv_obj.c \
../rt-thread/components/graphics/lvgl/src/core/lv_obj_class.c \
../rt-thread/components/graphics/lvgl/src/core/lv_obj_draw.c \
../rt-thread/components/graphics/lvgl/src/core/lv_obj_event.c \
../rt-thread/components/graphics/lvgl/src/core/lv_obj_id_builtin.c \
../rt-thread/components/graphics/lvgl/src/core/lv_obj_pos.c \
../rt-thread/components/graphics/lvgl/src/core/lv_obj_property.c \
../rt-thread/components/graphics/lvgl/src/core/lv_obj_scroll.c \
../rt-thread/components/graphics/lvgl/src/core/lv_obj_style.c \
../rt-thread/components/graphics/lvgl/src/core/lv_obj_style_gen.c \
../rt-thread/components/graphics/lvgl/src/core/lv_obj_tree.c \
../rt-thread/components/graphics/lvgl/src/core/lv_refr.c 

OBJS += \
./rt-thread/components/graphics/lvgl/src/core/lv_group.o \
./rt-thread/components/graphics/lvgl/src/core/lv_obj.o \
./rt-thread/components/graphics/lvgl/src/core/lv_obj_class.o \
./rt-thread/components/graphics/lvgl/src/core/lv_obj_draw.o \
./rt-thread/components/graphics/lvgl/src/core/lv_obj_event.o \
./rt-thread/components/graphics/lvgl/src/core/lv_obj_id_builtin.o \
./rt-thread/components/graphics/lvgl/src/core/lv_obj_pos.o \
./rt-thread/components/graphics/lvgl/src/core/lv_obj_property.o \
./rt-thread/components/graphics/lvgl/src/core/lv_obj_scroll.o \
./rt-thread/components/graphics/lvgl/src/core/lv_obj_style.o \
./rt-thread/components/graphics/lvgl/src/core/lv_obj_style_gen.o \
./rt-thread/components/graphics/lvgl/src/core/lv_obj_tree.o \
./rt-thread/components/graphics/lvgl/src/core/lv_refr.o 

C_DEPS += \
./rt-thread/components/graphics/lvgl/src/core/lv_group.d \
./rt-thread/components/graphics/lvgl/src/core/lv_obj.d \
./rt-thread/components/graphics/lvgl/src/core/lv_obj_class.d \
./rt-thread/components/graphics/lvgl/src/core/lv_obj_draw.d \
./rt-thread/components/graphics/lvgl/src/core/lv_obj_event.d \
./rt-thread/components/graphics/lvgl/src/core/lv_obj_id_builtin.d \
./rt-thread/components/graphics/lvgl/src/core/lv_obj_pos.d \
./rt-thread/components/graphics/lvgl/src/core/lv_obj_property.d \
./rt-thread/components/graphics/lvgl/src/core/lv_obj_scroll.d \
./rt-thread/components/graphics/lvgl/src/core/lv_obj_style.d \
./rt-thread/components/graphics/lvgl/src/core/lv_obj_style_gen.d \
./rt-thread/components/graphics/lvgl/src/core/lv_obj_tree.d \
./rt-thread/components/graphics/lvgl/src/core/lv_refr.d 


# Each subdirectory must supply rules for building sources it contributes
rt-thread/components/graphics/lvgl/src/core/%.o: ../rt-thread/components/graphics/lvgl/src/core/%.c
	arm-none-eabi-gcc -mtune=cortex-a7 -march=armv7-a -mfloat-abi=hard -mfpu=vfpv4 -O2 -ftree-vectorize -ffast-math -Wall  -g -gdwarf-2 -DRT_USING_NEWLIBC -DRT_USING_LIBC -D_POSIX_C_SOURCE=1 -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include\libadt\bitmap" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include\libadt\ref" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include\kconfig\rk3506" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\applications" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\platform\drivers\pwm" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\industrial_bus\CanFestival\inc" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\data_parsers\cJSON" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\compilers\common\include" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\compilers\newlib" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\src" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\cplusplus" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\coredump" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\perfetto" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\adc" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\gpio" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\hwtimer" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\mdio" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\mtd" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\pwm" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\rtc" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\touch" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\filesystem\include" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\platform\drivers\ad7606" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\platform\drivers\flexbus" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\platform\drivers\gt9xx" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\platform\drivers\hwtimer" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\platform\drivers\rtc" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\platform\drivers\sitronix" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\language\Lua\lua-5.3.4" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\language\Lua" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\dirent" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\fcntl" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\statfs" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\im2d_api" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\include" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\core" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\core\hardware" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\core\utils" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\core\adapter" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\core\3rdparty\libdrm\include\drm" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\lvgl\src" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\lvgl\port" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\lwip\lwip-2.1.2\src\include" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\lwip\lwip-2.1.2\src\include\netif" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\lwip\port" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\security\mbedtls\mbedtls\include" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\security\mbedtls\mbedtls\library" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\security\mbedtls\ports\inc" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\industrial_bus\libmodbus" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\ai\ncnn\inc" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\iperf2" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\net_apps\agile_ftp\inc" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\net_apps\pahomqtt\MQTTPacket\src" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\net_apps\pahomqtt\MQTTClient-RT" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\net_apps\telent" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\net_apps\tftp" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\net_apps\webclient\inc" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\posix\delay" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\posix\io\epoll" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\posix\io\eventfd" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\posix\io\poll" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\posix\io\stdio" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\posix\io\termios" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\posix\ipc" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\netdev\include" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\sal\include" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\sal\include\socket" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\sal\impl" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\sal\include\dfs_net" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\sal\include\socket\sys_socket" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\backtrace" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\finsh" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\industrial_bus\ethercat" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\loader\ota" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\rt_perf\inc" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\net_apps\webnet\inc" -std=c99 -fno-omit-frame-pointer -funwind-tables -fasynchronous-unwind-tables -DLINUX -DRT_THREAD -DRGA_SYNC_DISABLE -DRGA_UTILS_DRM_DISABLE -lm -D_USE_MATH_DEFINES -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

