rt-thread/components/graphics/lvgl/src/drivers/evdev/lv_evdev.o: \
 ../rt-thread/components/graphics/lvgl/src/drivers/evdev/lv_evdev.c \
 ../rt-thread/components/graphics/lvgl/src/drivers/evdev/lv_evdev.h \
 ../rt-thread/components/graphics/lvgl/src/drivers/evdev/../../indev/lv_indev.h \
 ../rt-thread/components/graphics/lvgl/src/drivers/evdev/../../indev/../core/lv_group.h \
 ../rt-thread/components/graphics/lvgl/src/drivers/evdev/../../indev/../core/../lv_conf_internal.h \
 ../rt-thread/components/graphics/lvgl/src/drivers/evdev/../../indev/../core/../lv_conf_kconfig.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\lvgl\port/lv_rt_thread_conf.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtthread.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176/rtconfig.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include\kconfig\rk3506/kconfig.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtdef.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtsched.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rttypes.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtcompiler.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rttypes.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kerrno.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/kpi.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtservice.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtm.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtatomic.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rthw.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtklibc.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kstring.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kstdio.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kerrno.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\finsh/finsh.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\finsh/finsh_service.h \
 ../rt-thread/components/graphics/lvgl/src/drivers/evdev/../../indev/../core/../misc/lv_types.h \
 g:\project\hand\tesla_hand\tesla_hand_temp_176\rt-thread\components\graphics\lvgl\src\lv_conf_internal.h \
 ../rt-thread/components/graphics/lvgl/src/drivers/evdev/../../indev/../core/../misc/lv_ll.h \
 ../rt-thread/components/graphics/lvgl/src/drivers/evdev/../../indev/../misc/lv_area.h \
 ../rt-thread/components/graphics/lvgl/src/drivers/evdev/../../indev/../misc/../lv_conf_internal.h \
 ../rt-thread/components/graphics/lvgl/src/drivers/evdev/../../indev/../misc/lv_types.h \
 ../rt-thread/components/graphics/lvgl/src/drivers/evdev/../../indev/../misc/lv_timer.h \
 ../rt-thread/components/graphics/lvgl/src/drivers/evdev/../../indev/../misc/../tick/lv_tick.h \
 g:\project\hand\tesla_hand\tesla_hand_temp_176\rt-thread\components\graphics\lvgl\src\lv_conf_internal.h \
 ../rt-thread/components/graphics/lvgl/src/drivers/evdev/../../indev/../misc/lv_ll.h \
 ../rt-thread/components/graphics/lvgl/src/drivers/evdev/../../indev/../misc/lv_event.h \
 ../rt-thread/components/graphics/lvgl/src/drivers/evdev/../../indev/../misc/lv_array.h
../rt-thread/components/graphics/lvgl/src/drivers/evdev/lv_evdev.h:
../rt-thread/components/graphics/lvgl/src/drivers/evdev/../../indev/lv_indev.h:
../rt-thread/components/graphics/lvgl/src/drivers/evdev/../../indev/../core/lv_group.h:
../rt-thread/components/graphics/lvgl/src/drivers/evdev/../../indev/../core/../lv_conf_internal.h:
../rt-thread/components/graphics/lvgl/src/drivers/evdev/../../indev/../core/../lv_conf_kconfig.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\lvgl\port/lv_rt_thread_conf.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtthread.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176/rtconfig.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include\kconfig\rk3506/kconfig.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtdef.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtsched.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rttypes.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtcompiler.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rttypes.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kerrno.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/kpi.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtservice.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtm.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtatomic.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rthw.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtklibc.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kstring.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kstdio.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kerrno.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\finsh/finsh.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\finsh/finsh_service.h:
../rt-thread/components/graphics/lvgl/src/drivers/evdev/../../indev/../core/../misc/lv_types.h:
g:\project\hand\tesla_hand\tesla_hand_temp_176\rt-thread\components\graphics\lvgl\src\lv_conf_internal.h:
../rt-thread/components/graphics/lvgl/src/drivers/evdev/../../indev/../core/../misc/lv_ll.h:
../rt-thread/components/graphics/lvgl/src/drivers/evdev/../../indev/../misc/lv_area.h:
../rt-thread/components/graphics/lvgl/src/drivers/evdev/../../indev/../misc/../lv_conf_internal.h:
../rt-thread/components/graphics/lvgl/src/drivers/evdev/../../indev/../misc/lv_types.h:
../rt-thread/components/graphics/lvgl/src/drivers/evdev/../../indev/../misc/lv_timer.h:
../rt-thread/components/graphics/lvgl/src/drivers/evdev/../../indev/../misc/../tick/lv_tick.h:
g:\project\hand\tesla_hand\tesla_hand_temp_176\rt-thread\components\graphics\lvgl\src\lv_conf_internal.h:
../rt-thread/components/graphics/lvgl/src/drivers/evdev/../../indev/../misc/lv_ll.h:
../rt-thread/components/graphics/lvgl/src/drivers/evdev/../../indev/../misc/lv_event.h:
../rt-thread/components/graphics/lvgl/src/drivers/evdev/../../indev/../misc/lv_array.h:
