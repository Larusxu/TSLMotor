rt-thread/components/graphics/lvgl/src/widgets/objx_templ/lv_objx_templ.o: \
 ../rt-thread/components/graphics/lvgl/src/widgets/objx_templ/lv_objx_templ.c
