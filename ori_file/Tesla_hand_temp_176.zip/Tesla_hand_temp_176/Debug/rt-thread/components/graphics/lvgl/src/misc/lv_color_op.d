rt-thread/components/graphics/lvgl/src/misc/lv_color_op.o: \
 ../rt-thread/components/graphics/lvgl/src/misc/lv_color_op.c \
 ../rt-thread/components/graphics/lvgl/src/misc/lv_color.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../lv_conf_internal.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../lv_conf_kconfig.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\lvgl\port/lv_rt_thread_conf.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtthread.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176/rtconfig.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include\kconfig\rk3506/kconfig.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtdef.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtsched.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rttypes.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtcompiler.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rttypes.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kerrno.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/kpi.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtservice.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtm.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtatomic.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rthw.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtklibc.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kstring.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kstdio.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kerrno.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\finsh/finsh.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\finsh/finsh_service.h \
 ../rt-thread/components/graphics/lvgl/src/misc/lv_assert.h \
 ../rt-thread/components/graphics/lvgl/src/misc/lv_log.h \
 ../rt-thread/components/graphics/lvgl/src/misc/lv_types.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../stdlib/lv_mem.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../stdlib/../lv_conf_internal.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../stdlib/../misc/lv_types.h \
 ../rt-thread/components/graphics/lvgl/src/misc/lv_math.h \
 ../rt-thread/components/graphics/lvgl/src/misc/lv_palette.h \
 ../rt-thread/components/graphics/lvgl/src/misc/lv_color_op.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../misc/lv_color.h
../rt-thread/components/graphics/lvgl/src/misc/lv_color.h:
../rt-thread/components/graphics/lvgl/src/misc/../lv_conf_internal.h:
../rt-thread/components/graphics/lvgl/src/misc/../lv_conf_kconfig.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\lvgl\port/lv_rt_thread_conf.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtthread.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176/rtconfig.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include\kconfig\rk3506/kconfig.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtdef.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtsched.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rttypes.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtcompiler.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rttypes.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kerrno.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/kpi.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtservice.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtm.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtatomic.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rthw.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtklibc.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kstring.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kstdio.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kerrno.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\finsh/finsh.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\finsh/finsh_service.h:
../rt-thread/components/graphics/lvgl/src/misc/lv_assert.h:
../rt-thread/components/graphics/lvgl/src/misc/lv_log.h:
../rt-thread/components/graphics/lvgl/src/misc/lv_types.h:
../rt-thread/components/graphics/lvgl/src/misc/../stdlib/lv_mem.h:
../rt-thread/components/graphics/lvgl/src/misc/../stdlib/../lv_conf_internal.h:
../rt-thread/components/graphics/lvgl/src/misc/../stdlib/../misc/lv_types.h:
../rt-thread/components/graphics/lvgl/src/misc/lv_math.h:
../rt-thread/components/graphics/lvgl/src/misc/lv_palette.h:
../rt-thread/components/graphics/lvgl/src/misc/lv_color_op.h:
../rt-thread/components/graphics/lvgl/src/misc/../misc/lv_color.h:
