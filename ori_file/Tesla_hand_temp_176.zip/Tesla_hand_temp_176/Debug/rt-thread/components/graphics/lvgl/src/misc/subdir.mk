################################################################################
# 自动生成的文件。不要编辑！
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../rt-thread/components/graphics/lvgl/src/misc/lv_anim.c \
../rt-thread/components/graphics/lvgl/src/misc/lv_anim_timeline.c \
../rt-thread/components/graphics/lvgl/src/misc/lv_area.c \
../rt-thread/components/graphics/lvgl/src/misc/lv_array.c \
../rt-thread/components/graphics/lvgl/src/misc/lv_async.c \
../rt-thread/components/graphics/lvgl/src/misc/lv_bidi.c \
../rt-thread/components/graphics/lvgl/src/misc/lv_color.c \
../rt-thread/components/graphics/lvgl/src/misc/lv_color_op.c \
../rt-thread/components/graphics/lvgl/src/misc/lv_event.c \
../rt-thread/components/graphics/lvgl/src/misc/lv_fs.c \
../rt-thread/components/graphics/lvgl/src/misc/lv_ll.c \
../rt-thread/components/graphics/lvgl/src/misc/lv_log.c \
../rt-thread/components/graphics/lvgl/src/misc/lv_lru.c \
../rt-thread/components/graphics/lvgl/src/misc/lv_math.c \
../rt-thread/components/graphics/lvgl/src/misc/lv_palette.c \
../rt-thread/components/graphics/lvgl/src/misc/lv_profiler_builtin.c \
../rt-thread/components/graphics/lvgl/src/misc/lv_rb.c \
../rt-thread/components/graphics/lvgl/src/misc/lv_style.c \
../rt-thread/components/graphics/lvgl/src/misc/lv_style_gen.c \
../rt-thread/components/graphics/lvgl/src/misc/lv_templ.c \
../rt-thread/components/graphics/lvgl/src/misc/lv_text.c \
../rt-thread/components/graphics/lvgl/src/misc/lv_text_ap.c \
../rt-thread/components/graphics/lvgl/src/misc/lv_timer.c \
../rt-thread/components/graphics/lvgl/src/misc/lv_utils.c 

OBJS += \
./rt-thread/components/graphics/lvgl/src/misc/lv_anim.o \
./rt-thread/components/graphics/lvgl/src/misc/lv_anim_timeline.o \
./rt-thread/components/graphics/lvgl/src/misc/lv_area.o \
./rt-thread/components/graphics/lvgl/src/misc/lv_array.o \
./rt-thread/components/graphics/lvgl/src/misc/lv_async.o \
./rt-thread/components/graphics/lvgl/src/misc/lv_bidi.o \
./rt-thread/components/graphics/lvgl/src/misc/lv_color.o \
./rt-thread/components/graphics/lvgl/src/misc/lv_color_op.o \
./rt-thread/components/graphics/lvgl/src/misc/lv_event.o \
./rt-thread/components/graphics/lvgl/src/misc/lv_fs.o \
./rt-thread/components/graphics/lvgl/src/misc/lv_ll.o \
./rt-thread/components/graphics/lvgl/src/misc/lv_log.o \
./rt-thread/components/graphics/lvgl/src/misc/lv_lru.o \
./rt-thread/components/graphics/lvgl/src/misc/lv_math.o \
./rt-thread/components/graphics/lvgl/src/misc/lv_palette.o \
./rt-thread/components/graphics/lvgl/src/misc/lv_profiler_builtin.o \
./rt-thread/components/graphics/lvgl/src/misc/lv_rb.o \
./rt-thread/components/graphics/lvgl/src/misc/lv_style.o \
./rt-thread/components/graphics/lvgl/src/misc/lv_style_gen.o \
./rt-thread/components/graphics/lvgl/src/misc/lv_templ.o \
./rt-thread/components/graphics/lvgl/src/misc/lv_text.o \
./rt-thread/components/graphics/lvgl/src/misc/lv_text_ap.o \
./rt-thread/components/graphics/lvgl/src/misc/lv_timer.o \
./rt-thread/components/graphics/lvgl/src/misc/lv_utils.o 

C_DEPS += \
./rt-thread/components/graphics/lvgl/src/misc/lv_anim.d \
./rt-thread/components/graphics/lvgl/src/misc/lv_anim_timeline.d \
./rt-thread/components/graphics/lvgl/src/misc/lv_area.d \
./rt-thread/components/graphics/lvgl/src/misc/lv_array.d \
./rt-thread/components/graphics/lvgl/src/misc/lv_async.d \
./rt-thread/components/graphics/lvgl/src/misc/lv_bidi.d \
./rt-thread/components/graphics/lvgl/src/misc/lv_color.d \
./rt-thread/components/graphics/lvgl/src/misc/lv_color_op.d \
./rt-thread/components/graphics/lvgl/src/misc/lv_event.d \
./rt-thread/components/graphics/lvgl/src/misc/lv_fs.d \
./rt-thread/components/graphics/lvgl/src/misc/lv_ll.d \
./rt-thread/components/graphics/lvgl/src/misc/lv_log.d \
./rt-thread/components/graphics/lvgl/src/misc/lv_lru.d \
./rt-thread/components/graphics/lvgl/src/misc/lv_math.d \
./rt-thread/components/graphics/lvgl/src/misc/lv_palette.d \
./rt-thread/components/graphics/lvgl/src/misc/lv_profiler_builtin.d \
./rt-thread/components/graphics/lvgl/src/misc/lv_rb.d \
./rt-thread/components/graphics/lvgl/src/misc/lv_style.d \
./rt-thread/components/graphics/lvgl/src/misc/lv_style_gen.d \
./rt-thread/components/graphics/lvgl/src/misc/lv_templ.d \
./rt-thread/components/graphics/lvgl/src/misc/lv_text.d \
./rt-thread/components/graphics/lvgl/src/misc/lv_text_ap.d \
./rt-thread/components/graphics/lvgl/src/misc/lv_timer.d \
./rt-thread/components/graphics/lvgl/src/misc/lv_utils.d 


# Each subdirectory must supply rules for building sources it contributes
rt-thread/components/graphics/lvgl/src/misc/%.o: ../rt-thread/components/graphics/lvgl/src/misc/%.c
	arm-none-eabi-gcc -mtune=cortex-a7 -march=armv7-a -mfloat-abi=hard -mfpu=vfpv4 -O2 -ftree-vectorize -ffast-math -Wall  -g -gdwarf-2 -DRT_USING_NEWLIBC -DRT_USING_LIBC -D_POSIX_C_SOURCE=1 -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include\libadt\bitmap" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include\libadt\ref" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include\kconfig\rk3506" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\applications" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\platform\drivers\pwm" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\industrial_bus\CanFestival\inc" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\data_parsers\cJSON" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\compilers\common\include" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\compilers\newlib" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\src" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\cplusplus" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\coredump" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\perfetto" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\adc" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\gpio" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\hwtimer" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\mdio" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\mtd" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\pwm" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\rtc" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\touch" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\filesystem\include" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\platform\drivers\ad7606" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\platform\drivers\flexbus" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\platform\drivers\gt9xx" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\platform\drivers\hwtimer" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\platform\drivers\rtc" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\platform\drivers\sitronix" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\language\Lua\lua-5.3.4" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\language\Lua" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\dirent" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\fcntl" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\statfs" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\im2d_api" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\include" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\core" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\core\hardware" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\core\utils" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\core\adapter" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\core\3rdparty\libdrm\include\drm" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\lvgl\src" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\lvgl\port" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\lwip\lwip-2.1.2\src\include" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\lwip\lwip-2.1.2\src\include\netif" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\lwip\port" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\security\mbedtls\mbedtls\include" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\security\mbedtls\mbedtls\library" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\security\mbedtls\ports\inc" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\industrial_bus\libmodbus" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\ai\ncnn\inc" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\iperf2" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\net_apps\agile_ftp\inc" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\net_apps\pahomqtt\MQTTPacket\src" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\net_apps\pahomqtt\MQTTClient-RT" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\net_apps\telent" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\net_apps\tftp" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\net_apps\webclient\inc" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\posix\delay" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\posix\io\epoll" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\posix\io\eventfd" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\posix\io\poll" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\posix\io\stdio" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\posix\io\termios" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\posix\ipc" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\netdev\include" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\sal\include" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\sal\include\socket" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\sal\impl" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\sal\include\dfs_net" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\sal\include\socket\sys_socket" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\backtrace" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\finsh" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\industrial_bus\ethercat" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\loader\ota" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\rt_perf\inc" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\net_apps\webnet\inc" -std=c99 -fno-omit-frame-pointer -funwind-tables -fasynchronous-unwind-tables -DLINUX -DRT_THREAD -DRGA_SYNC_DISABLE -DRGA_UTILS_DRM_DISABLE -lm -D_USE_MATH_DEFINES -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

