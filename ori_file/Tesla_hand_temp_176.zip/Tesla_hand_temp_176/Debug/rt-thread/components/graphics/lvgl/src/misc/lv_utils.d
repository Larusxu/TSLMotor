rt-thread/components/graphics/lvgl/src/misc/lv_utils.o: \
 ../rt-thread/components/graphics/lvgl/src/misc/lv_utils.c \
 ../rt-thread/components/graphics/lvgl/src/misc/lv_utils.h \
 ../rt-thread/components/graphics/lvgl/src/misc/lv_types.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../lv_conf_internal.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../lv_conf_kconfig.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\lvgl\port/lv_rt_thread_conf.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtthread.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176/rtconfig.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include\kconfig\rk3506/kconfig.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtdef.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtsched.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rttypes.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtcompiler.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rttypes.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kerrno.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/kpi.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtservice.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtm.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtatomic.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rthw.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtklibc.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kstring.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kstdio.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kerrno.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\finsh/finsh.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\finsh/finsh_service.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/lv_draw_buf.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_area.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/../lv_conf_internal.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_types.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_color.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_assert.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_log.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/../stdlib/lv_mem.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/../stdlib/../lv_conf_internal.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/../stdlib/../misc/lv_types.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_math.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_palette.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_color.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_color_op.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../stdlib/lv_string.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../stdlib/../lv_conf_internal.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/lv_image_dsc.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../lv_conf_internal.h \
 ../rt-thread/components/graphics/lvgl/src/misc/lv_fs.h \
 ../rt-thread/components/graphics/lvgl/src/misc/cache/lv_image_cache.h \
 ../rt-thread/components/graphics/lvgl/src/misc/cache/lv_cache_private.h \
 ../rt-thread/components/graphics/lvgl/src/misc/cache/../lv_types.h \
 ../rt-thread/components/graphics/lvgl/src/misc/cache/../../osal/lv_os.h \
 ../rt-thread/components/graphics/lvgl/src/misc/cache/../../osal/../lv_conf_internal.h \
 ../rt-thread/components/graphics/lvgl/src/misc/cache/../../osal/../misc/lv_types.h \
 ../rt-thread/components/graphics/lvgl/src/misc/cache/../../osal/lv_rtthread.h
../rt-thread/components/graphics/lvgl/src/misc/lv_utils.h:
../rt-thread/components/graphics/lvgl/src/misc/lv_types.h:
../rt-thread/components/graphics/lvgl/src/misc/../lv_conf_internal.h:
../rt-thread/components/graphics/lvgl/src/misc/../lv_conf_kconfig.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\lvgl\port/lv_rt_thread_conf.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtthread.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176/rtconfig.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include\kconfig\rk3506/kconfig.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtdef.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtsched.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rttypes.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtcompiler.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rttypes.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kerrno.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/kpi.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtservice.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtm.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtatomic.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rthw.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtklibc.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kstring.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kstdio.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kerrno.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\finsh/finsh.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\finsh/finsh_service.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/lv_draw_buf.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_area.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/../lv_conf_internal.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_types.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_color.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_assert.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_log.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/../stdlib/lv_mem.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/../stdlib/../lv_conf_internal.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/../stdlib/../misc/lv_types.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_math.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_palette.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_color.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_color_op.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../stdlib/lv_string.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../stdlib/../lv_conf_internal.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/lv_image_dsc.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../lv_conf_internal.h:
../rt-thread/components/graphics/lvgl/src/misc/lv_fs.h:
../rt-thread/components/graphics/lvgl/src/misc/cache/lv_image_cache.h:
../rt-thread/components/graphics/lvgl/src/misc/cache/lv_cache_private.h:
../rt-thread/components/graphics/lvgl/src/misc/cache/../lv_types.h:
../rt-thread/components/graphics/lvgl/src/misc/cache/../../osal/lv_os.h:
../rt-thread/components/graphics/lvgl/src/misc/cache/../../osal/../lv_conf_internal.h:
../rt-thread/components/graphics/lvgl/src/misc/cache/../../osal/../misc/lv_types.h:
../rt-thread/components/graphics/lvgl/src/misc/cache/../../osal/lv_rtthread.h:
