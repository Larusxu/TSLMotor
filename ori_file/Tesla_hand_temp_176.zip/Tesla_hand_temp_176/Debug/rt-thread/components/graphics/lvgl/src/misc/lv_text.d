rt-thread/components/graphics/lvgl/src/misc/lv_text.o: \
 ../rt-thread/components/graphics/lvgl/src/misc/lv_text.c \
 ../rt-thread/components/graphics/lvgl/src/misc/lv_text.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../lv_conf_internal.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../lv_conf_kconfig.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\lvgl\port/lv_rt_thread_conf.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtthread.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176/rtconfig.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include\kconfig\rk3506/kconfig.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtdef.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtsched.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rttypes.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtcompiler.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rttypes.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kerrno.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/kpi.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtservice.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtm.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtatomic.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rthw.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtklibc.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kstring.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kstdio.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kerrno.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\finsh/finsh.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\finsh/finsh_service.h \
 ../rt-thread/components/graphics/lvgl/src/misc/lv_area.h \
 ../rt-thread/components/graphics/lvgl/src/misc/lv_types.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../font/lv_font.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../font/../lv_conf_internal.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../font/lv_symbol_def.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../font/../draw/lv_draw_buf.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../font/../draw/../misc/lv_area.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../font/../draw/../misc/lv_color.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../font/../draw/../misc/../lv_conf_internal.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../font/../draw/../misc/lv_assert.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../font/../draw/../misc/lv_log.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../font/../draw/../misc/lv_types.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../font/../draw/../misc/../stdlib/lv_mem.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../font/../draw/../misc/../stdlib/../lv_conf_internal.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../font/../draw/../misc/../stdlib/../misc/lv_types.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../font/../draw/../misc/lv_math.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../font/../draw/../misc/lv_palette.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../font/../draw/../misc/lv_color.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../font/../draw/../misc/lv_color_op.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../font/../draw/../stdlib/lv_string.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../font/../draw/../stdlib/../lv_conf_internal.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../font/../draw/lv_image_dsc.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../font/../draw/../lv_conf_internal.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../font/../misc/lv_area.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../font/../misc/lv_types.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../font/../misc/cache/lv_cache.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../font/../misc/cache/lv_cache_entry.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../font/../misc/cache/../../osal/lv_os.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../font/../misc/cache/../../osal/../lv_conf_internal.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../font/../misc/cache/../../osal/../misc/lv_types.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../font/../misc/cache/../../osal/lv_rtthread.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../font/../misc/cache/../lv_types.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../font/../misc/cache/lv_cache_private.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../font/../misc/cache/_lv_cache_lru_rb.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../font/../misc/cache/lv_image_cache.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../stdlib/lv_sprintf.h \
 ../rt-thread/components/graphics/lvgl/src/misc/lv_text_ap.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/lv_draw.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../lv_conf_internal.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_types.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_style.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/../font/lv_font.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_color.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_area.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_anim.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/../lv_conf_internal.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_types.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_math.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_timer.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/../tick/lv_tick.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/../tick/../lv_conf_internal.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_ll.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_text.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_assert.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_bidi.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/../layouts/lv_layout.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/../layouts/../lv_conf_internal.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/../layouts/../misc/lv_types.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/../layouts/flex/lv_flex.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/../layouts/flex/../../lv_conf_internal.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/../layouts/flex/../../misc/lv_area.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/../layouts/grid/lv_grid.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/../layouts/grid/../../lv_conf_internal.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/../layouts/grid/../../misc/lv_area.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_style_gen.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_text.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_profiler.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/lv_image_decoder.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/lv_draw_buf.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_fs.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_area.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/cache/lv_cache.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../osal/lv_os.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/lv_draw_rect.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/lv_draw.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_color.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/sw/lv_draw_sw_gradient.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/sw/../../misc/lv_color.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/sw/../../misc/lv_style.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/lv_draw_label.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_bidi.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/lv_draw_image.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/lv_draw_arc.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/lv_draw_line.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/lv_draw_triangle.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../draw/lv_draw_mask.h \
 ../rt-thread/components/graphics/lvgl/src/misc/lv_math.h \
 ../rt-thread/components/graphics/lvgl/src/misc/lv_log.h \
 ../rt-thread/components/graphics/lvgl/src/misc/lv_assert.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../stdlib/lv_mem.h \
 ../rt-thread/components/graphics/lvgl/src/misc/../stdlib/lv_string.h
../rt-thread/components/graphics/lvgl/src/misc/lv_text.h:
../rt-thread/components/graphics/lvgl/src/misc/../lv_conf_internal.h:
../rt-thread/components/graphics/lvgl/src/misc/../lv_conf_kconfig.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\lvgl\port/lv_rt_thread_conf.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtthread.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176/rtconfig.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include\kconfig\rk3506/kconfig.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtdef.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtsched.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rttypes.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtcompiler.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rttypes.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kerrno.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/kpi.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtservice.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtm.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtatomic.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rthw.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtklibc.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kstring.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kstdio.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kerrno.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\finsh/finsh.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\finsh/finsh_service.h:
../rt-thread/components/graphics/lvgl/src/misc/lv_area.h:
../rt-thread/components/graphics/lvgl/src/misc/lv_types.h:
../rt-thread/components/graphics/lvgl/src/misc/../font/lv_font.h:
../rt-thread/components/graphics/lvgl/src/misc/../font/../lv_conf_internal.h:
../rt-thread/components/graphics/lvgl/src/misc/../font/lv_symbol_def.h:
../rt-thread/components/graphics/lvgl/src/misc/../font/../draw/lv_draw_buf.h:
../rt-thread/components/graphics/lvgl/src/misc/../font/../draw/../misc/lv_area.h:
../rt-thread/components/graphics/lvgl/src/misc/../font/../draw/../misc/lv_color.h:
../rt-thread/components/graphics/lvgl/src/misc/../font/../draw/../misc/../lv_conf_internal.h:
../rt-thread/components/graphics/lvgl/src/misc/../font/../draw/../misc/lv_assert.h:
../rt-thread/components/graphics/lvgl/src/misc/../font/../draw/../misc/lv_log.h:
../rt-thread/components/graphics/lvgl/src/misc/../font/../draw/../misc/lv_types.h:
../rt-thread/components/graphics/lvgl/src/misc/../font/../draw/../misc/../stdlib/lv_mem.h:
../rt-thread/components/graphics/lvgl/src/misc/../font/../draw/../misc/../stdlib/../lv_conf_internal.h:
../rt-thread/components/graphics/lvgl/src/misc/../font/../draw/../misc/../stdlib/../misc/lv_types.h:
../rt-thread/components/graphics/lvgl/src/misc/../font/../draw/../misc/lv_math.h:
../rt-thread/components/graphics/lvgl/src/misc/../font/../draw/../misc/lv_palette.h:
../rt-thread/components/graphics/lvgl/src/misc/../font/../draw/../misc/lv_color.h:
../rt-thread/components/graphics/lvgl/src/misc/../font/../draw/../misc/lv_color_op.h:
../rt-thread/components/graphics/lvgl/src/misc/../font/../draw/../stdlib/lv_string.h:
../rt-thread/components/graphics/lvgl/src/misc/../font/../draw/../stdlib/../lv_conf_internal.h:
../rt-thread/components/graphics/lvgl/src/misc/../font/../draw/lv_image_dsc.h:
../rt-thread/components/graphics/lvgl/src/misc/../font/../draw/../lv_conf_internal.h:
../rt-thread/components/graphics/lvgl/src/misc/../font/../misc/lv_area.h:
../rt-thread/components/graphics/lvgl/src/misc/../font/../misc/lv_types.h:
../rt-thread/components/graphics/lvgl/src/misc/../font/../misc/cache/lv_cache.h:
../rt-thread/components/graphics/lvgl/src/misc/../font/../misc/cache/lv_cache_entry.h:
../rt-thread/components/graphics/lvgl/src/misc/../font/../misc/cache/../../osal/lv_os.h:
../rt-thread/components/graphics/lvgl/src/misc/../font/../misc/cache/../../osal/../lv_conf_internal.h:
../rt-thread/components/graphics/lvgl/src/misc/../font/../misc/cache/../../osal/../misc/lv_types.h:
../rt-thread/components/graphics/lvgl/src/misc/../font/../misc/cache/../../osal/lv_rtthread.h:
../rt-thread/components/graphics/lvgl/src/misc/../font/../misc/cache/../lv_types.h:
../rt-thread/components/graphics/lvgl/src/misc/../font/../misc/cache/lv_cache_private.h:
../rt-thread/components/graphics/lvgl/src/misc/../font/../misc/cache/_lv_cache_lru_rb.h:
../rt-thread/components/graphics/lvgl/src/misc/../font/../misc/cache/lv_image_cache.h:
../rt-thread/components/graphics/lvgl/src/misc/../stdlib/lv_sprintf.h:
../rt-thread/components/graphics/lvgl/src/misc/lv_text_ap.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/lv_draw.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../lv_conf_internal.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_types.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_style.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/../font/lv_font.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_color.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_area.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_anim.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/../lv_conf_internal.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_types.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_math.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_timer.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/../tick/lv_tick.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/../tick/../lv_conf_internal.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_ll.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_text.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_assert.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_bidi.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/../layouts/lv_layout.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/../layouts/../lv_conf_internal.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/../layouts/../misc/lv_types.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/../layouts/flex/lv_flex.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/../layouts/flex/../../lv_conf_internal.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/../layouts/flex/../../misc/lv_area.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/../layouts/grid/lv_grid.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/../layouts/grid/../../lv_conf_internal.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/../layouts/grid/../../misc/lv_area.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_style_gen.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_text.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_profiler.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/lv_image_decoder.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/lv_draw_buf.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_fs.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_area.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/cache/lv_cache.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../osal/lv_os.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/lv_draw_rect.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/lv_draw.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_color.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/sw/lv_draw_sw_gradient.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/sw/../../misc/lv_color.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/sw/../../misc/lv_style.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/lv_draw_label.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/../misc/lv_bidi.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/lv_draw_image.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/lv_draw_arc.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/lv_draw_line.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/lv_draw_triangle.h:
../rt-thread/components/graphics/lvgl/src/misc/../draw/lv_draw_mask.h:
../rt-thread/components/graphics/lvgl/src/misc/lv_math.h:
../rt-thread/components/graphics/lvgl/src/misc/lv_log.h:
../rt-thread/components/graphics/lvgl/src/misc/lv_assert.h:
../rt-thread/components/graphics/lvgl/src/misc/../stdlib/lv_mem.h:
../rt-thread/components/graphics/lvgl/src/misc/../stdlib/lv_string.h:
