rt-thread/components/graphics/lvgl/src/libs/tjpgd/tjpgd.o: \
 ../rt-thread/components/graphics/lvgl/src/libs/tjpgd/tjpgd.c \
 ../rt-thread/components/graphics/lvgl/src/libs/tjpgd/tjpgd.h \
 ../rt-thread/components/graphics/lvgl/src/libs/tjpgd/tjpgdcnf.h
../rt-thread/components/graphics/lvgl/src/libs/tjpgd/tjpgd.h:
../rt-thread/components/graphics/lvgl/src/libs/tjpgd/tjpgdcnf.h:
