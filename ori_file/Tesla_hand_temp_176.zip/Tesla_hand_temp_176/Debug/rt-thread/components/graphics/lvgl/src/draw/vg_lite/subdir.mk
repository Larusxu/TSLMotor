################################################################################
# 自动生成的文件。不要编辑！
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_draw_buf_vg_lite.c \
../rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_draw_vg_lite.c \
../rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_draw_vg_lite_arc.c \
../rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_draw_vg_lite_border.c \
../rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_draw_vg_lite_box_shadow.c \
../rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_draw_vg_lite_fill.c \
../rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_draw_vg_lite_img.c \
../rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_draw_vg_lite_label.c \
../rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_draw_vg_lite_layer.c \
../rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_draw_vg_lite_line.c \
../rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_draw_vg_lite_mask_rect.c \
../rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_draw_vg_lite_triangle.c \
../rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_draw_vg_lite_vector.c \
../rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_vg_lite_decoder.c \
../rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_vg_lite_grad.c \
../rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_vg_lite_math.c \
../rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_vg_lite_path.c \
../rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_vg_lite_pending.c \
../rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_vg_lite_utils.c 

OBJS += \
./rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_draw_buf_vg_lite.o \
./rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_draw_vg_lite.o \
./rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_draw_vg_lite_arc.o \
./rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_draw_vg_lite_border.o \
./rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_draw_vg_lite_box_shadow.o \
./rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_draw_vg_lite_fill.o \
./rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_draw_vg_lite_img.o \
./rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_draw_vg_lite_label.o \
./rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_draw_vg_lite_layer.o \
./rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_draw_vg_lite_line.o \
./rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_draw_vg_lite_mask_rect.o \
./rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_draw_vg_lite_triangle.o \
./rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_draw_vg_lite_vector.o \
./rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_vg_lite_decoder.o \
./rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_vg_lite_grad.o \
./rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_vg_lite_math.o \
./rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_vg_lite_path.o \
./rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_vg_lite_pending.o \
./rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_vg_lite_utils.o 

C_DEPS += \
./rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_draw_buf_vg_lite.d \
./rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_draw_vg_lite.d \
./rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_draw_vg_lite_arc.d \
./rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_draw_vg_lite_border.d \
./rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_draw_vg_lite_box_shadow.d \
./rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_draw_vg_lite_fill.d \
./rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_draw_vg_lite_img.d \
./rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_draw_vg_lite_label.d \
./rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_draw_vg_lite_layer.d \
./rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_draw_vg_lite_line.d \
./rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_draw_vg_lite_mask_rect.d \
./rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_draw_vg_lite_triangle.d \
./rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_draw_vg_lite_vector.d \
./rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_vg_lite_decoder.d \
./rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_vg_lite_grad.d \
./rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_vg_lite_math.d \
./rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_vg_lite_path.d \
./rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_vg_lite_pending.d \
./rt-thread/components/graphics/lvgl/src/draw/vg_lite/lv_vg_lite_utils.d 


# Each subdirectory must supply rules for building sources it contributes
rt-thread/components/graphics/lvgl/src/draw/vg_lite/%.o: ../rt-thread/components/graphics/lvgl/src/draw/vg_lite/%.c
	arm-none-eabi-gcc -mtune=cortex-a7 -march=armv7-a -mfloat-abi=hard -mfpu=vfpv4 -O2 -ftree-vectorize -ffast-math -Wall  -g -gdwarf-2 -DRT_USING_NEWLIBC -DRT_USING_LIBC -D_POSIX_C_SOURCE=1 -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include\libadt\bitmap" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include\libadt\ref" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include\kconfig\rk3506" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\applications" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\platform\drivers\pwm" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\industrial_bus\CanFestival\inc" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\data_parsers\cJSON" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\compilers\common\include" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\compilers\newlib" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\src" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\cplusplus" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\coredump" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\perfetto" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\adc" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\gpio" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\hwtimer" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\mdio" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\mtd" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\pwm" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\rtc" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\touch" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\filesystem\include" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\platform\drivers\ad7606" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\platform\drivers\flexbus" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\platform\drivers\gt9xx" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\platform\drivers\hwtimer" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\platform\drivers\rtc" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\platform\drivers\sitronix" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\language\Lua\lua-5.3.4" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\language\Lua" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\dirent" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\fcntl" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\statfs" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\im2d_api" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\include" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\core" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\core\hardware" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\core\utils" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\core\adapter" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\core\3rdparty\libdrm\include\drm" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\lvgl\src" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\lvgl\port" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\lwip\lwip-2.1.2\src\include" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\lwip\lwip-2.1.2\src\include\netif" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\lwip\port" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\security\mbedtls\mbedtls\include" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\security\mbedtls\mbedtls\library" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\security\mbedtls\ports\inc" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\industrial_bus\libmodbus" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\ai\ncnn\inc" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\iperf2" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\net_apps\agile_ftp\inc" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\net_apps\pahomqtt\MQTTPacket\src" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\net_apps\pahomqtt\MQTTClient-RT" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\net_apps\telent" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\net_apps\tftp" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\net_apps\webclient\inc" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\posix\delay" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\posix\io\epoll" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\posix\io\eventfd" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\posix\io\poll" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\posix\io\stdio" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\posix\io\termios" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\posix\ipc" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\netdev\include" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\sal\include" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\sal\include\socket" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\sal\impl" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\sal\include\dfs_net" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\sal\include\socket\sys_socket" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\backtrace" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\finsh" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\industrial_bus\ethercat" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\loader\ota" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\rt_perf\inc" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\net_apps\webnet\inc" -std=c99 -fno-omit-frame-pointer -funwind-tables -fasynchronous-unwind-tables -DLINUX -DRT_THREAD -DRGA_SYNC_DISABLE -DRGA_UTILS_DRM_DISABLE -lm -D_USE_MATH_DEFINES -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

