rt-thread/components/graphics/lvgl/src/misc/lv_templ.o: \
 ../rt-thread/components/graphics/lvgl/src/misc/lv_templ.c
