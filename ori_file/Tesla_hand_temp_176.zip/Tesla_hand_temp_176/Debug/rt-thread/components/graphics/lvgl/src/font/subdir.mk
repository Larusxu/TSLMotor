################################################################################
# 自动生成的文件。不要编辑！
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../rt-thread/components/graphics/lvgl/src/font/lv_binfont_loader.c \
../rt-thread/components/graphics/lvgl/src/font/lv_font.c \
../rt-thread/components/graphics/lvgl/src/font/lv_font_dejavu_16_persian_hebrew.c \
../rt-thread/components/graphics/lvgl/src/font/lv_font_fmt_txt.c \
../rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_10.c \
../rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_12.c \
../rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_14.c \
../rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_16.c \
../rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_18.c \
../rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_20.c \
../rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_22.c \
../rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_24.c \
../rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_26.c \
../rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_28.c \
../rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_28_compressed.c \
../rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_30.c \
../rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_32.c \
../rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_34.c \
../rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_36.c \
../rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_38.c \
../rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_40.c \
../rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_42.c \
../rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_44.c \
../rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_46.c \
../rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_48.c \
../rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_8.c \
../rt-thread/components/graphics/lvgl/src/font/lv_font_simsun_16_cjk.c \
../rt-thread/components/graphics/lvgl/src/font/lv_font_unscii_16.c \
../rt-thread/components/graphics/lvgl/src/font/lv_font_unscii_8.c 

OBJS += \
./rt-thread/components/graphics/lvgl/src/font/lv_binfont_loader.o \
./rt-thread/components/graphics/lvgl/src/font/lv_font.o \
./rt-thread/components/graphics/lvgl/src/font/lv_font_dejavu_16_persian_hebrew.o \
./rt-thread/components/graphics/lvgl/src/font/lv_font_fmt_txt.o \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_10.o \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_12.o \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_14.o \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_16.o \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_18.o \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_20.o \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_22.o \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_24.o \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_26.o \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_28.o \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_28_compressed.o \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_30.o \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_32.o \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_34.o \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_36.o \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_38.o \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_40.o \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_42.o \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_44.o \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_46.o \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_48.o \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_8.o \
./rt-thread/components/graphics/lvgl/src/font/lv_font_simsun_16_cjk.o \
./rt-thread/components/graphics/lvgl/src/font/lv_font_unscii_16.o \
./rt-thread/components/graphics/lvgl/src/font/lv_font_unscii_8.o 

C_DEPS += \
./rt-thread/components/graphics/lvgl/src/font/lv_binfont_loader.d \
./rt-thread/components/graphics/lvgl/src/font/lv_font.d \
./rt-thread/components/graphics/lvgl/src/font/lv_font_dejavu_16_persian_hebrew.d \
./rt-thread/components/graphics/lvgl/src/font/lv_font_fmt_txt.d \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_10.d \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_12.d \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_14.d \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_16.d \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_18.d \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_20.d \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_22.d \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_24.d \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_26.d \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_28.d \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_28_compressed.d \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_30.d \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_32.d \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_34.d \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_36.d \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_38.d \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_40.d \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_42.d \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_44.d \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_46.d \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_48.d \
./rt-thread/components/graphics/lvgl/src/font/lv_font_montserrat_8.d \
./rt-thread/components/graphics/lvgl/src/font/lv_font_simsun_16_cjk.d \
./rt-thread/components/graphics/lvgl/src/font/lv_font_unscii_16.d \
./rt-thread/components/graphics/lvgl/src/font/lv_font_unscii_8.d 


# Each subdirectory must supply rules for building sources it contributes
rt-thread/components/graphics/lvgl/src/font/%.o: ../rt-thread/components/graphics/lvgl/src/font/%.c
	arm-none-eabi-gcc -mtune=cortex-a7 -march=armv7-a -mfloat-abi=hard -mfpu=vfpv4 -O2 -ftree-vectorize -ffast-math -Wall  -g -gdwarf-2 -DRT_USING_NEWLIBC -DRT_USING_LIBC -D_POSIX_C_SOURCE=1 -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include\libadt\bitmap" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include\libadt\ref" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include\kconfig\rk3506" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\applications" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\platform\drivers\pwm" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\industrial_bus\CanFestival\inc" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\data_parsers\cJSON" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\compilers\common\include" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\compilers\newlib" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\src" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\cplusplus" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\coredump" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\perfetto" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\adc" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\gpio" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\hwtimer" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\include" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\mdio" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\mtd" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\pwm" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\rtc" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\touch" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\filesystem\include" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\platform\drivers\ad7606" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\platform\drivers\flexbus" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\platform\drivers\gt9xx" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\platform\drivers\hwtimer" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\platform\drivers\rtc" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\platform\drivers\sitronix" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\language\Lua\lua-5.3.4" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\language\Lua" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\dirent" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\fcntl" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\statfs" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\im2d_api" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\include" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\core" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\core\hardware" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\core\utils" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\core\adapter" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\core\3rdparty\libdrm\include\drm" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\lvgl\src" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\lvgl\port" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\lwip\lwip-2.1.2\src\include" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\lwip\lwip-2.1.2\src\include\netif" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\lwip\port" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\security\mbedtls\mbedtls\include" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\security\mbedtls\mbedtls\library" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\security\mbedtls\ports\inc" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\industrial_bus\libmodbus" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\ai\ncnn\inc" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\iperf2" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\net_apps\agile_ftp\inc" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\net_apps\pahomqtt\MQTTPacket\src" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\net_apps\pahomqtt\MQTTClient-RT" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\net_apps\telent" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\net_apps\tftp" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\net_apps\webclient\inc" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\posix\delay" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\posix\io\epoll" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\posix\io\eventfd" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\posix\io\poll" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\posix\io\stdio" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\posix\io\termios" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\posix\ipc" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\netdev\include" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\sal\include" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\sal\include\socket" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\sal\impl" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\sal\include\dfs_net" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\drivers\net\sal\include\socket\sys_socket" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\backtrace" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\finsh" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\industrial_bus\ethercat" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\loader\ota" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\rt_perf\inc" -I"G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\net_apps\webnet\inc" -std=c99 -fno-omit-frame-pointer -funwind-tables -fasynchronous-unwind-tables -DLINUX -DRT_THREAD -DRGA_SYNC_DISABLE -DRGA_UTILS_DRM_DISABLE -lm -D_USE_MATH_DEFINES -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

