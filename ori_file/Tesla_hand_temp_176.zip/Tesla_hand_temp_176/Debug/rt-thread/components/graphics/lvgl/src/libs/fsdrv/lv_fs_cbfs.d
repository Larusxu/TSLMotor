rt-thread/components/graphics/lvgl/src/libs/fsdrv/lv_fs_cbfs.o: \
 ../rt-thread/components/graphics/lvgl/src/libs/fsdrv/lv_fs_cbfs.c
