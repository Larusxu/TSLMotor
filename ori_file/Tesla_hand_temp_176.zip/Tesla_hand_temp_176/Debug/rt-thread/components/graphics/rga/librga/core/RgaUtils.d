rt-thread/components/graphics/rga/librga/core/RgaUtils.o: \
 ../rt-thread/components/graphics/rga/librga/core/RgaUtils.c \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\compilers\newlib/fcntl.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\compilers\common\include/unistd.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\compilers\common\include/sys/unistd.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/kpi.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rttypes.h \
 ../rt-thread/components/graphics/rga/librga/core/utils/utils.h \
 ../rt-thread/components/graphics/rga/librga/core/utils/android_utils/android_utils.h \
 ../rt-thread/components/graphics/rga/librga/core/utils/drm_utils/drm_utils.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\include/RgaUtils.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\include/rga.h
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\compilers\newlib/fcntl.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\compilers\common\include/unistd.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\compilers\common\include/sys/unistd.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/kpi.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rttypes.h:
../rt-thread/components/graphics/rga/librga/core/utils/utils.h:
../rt-thread/components/graphics/rga/librga/core/utils/android_utils/android_utils.h:
../rt-thread/components/graphics/rga/librga/core/utils/drm_utils/drm_utils.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\include/RgaUtils.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\include/rga.h:
