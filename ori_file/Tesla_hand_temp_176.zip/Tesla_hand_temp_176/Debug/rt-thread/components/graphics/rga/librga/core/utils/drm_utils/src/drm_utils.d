rt-thread/components/graphics/rga/librga/core/utils/drm_utils/src/drm_utils.o: \
 ../rt-thread/components/graphics/rga/librga/core/utils/drm_utils/src/drm_utils.c \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\core\utils/drm_utils/drm_utils.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\include/rga.h
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\core\utils/drm_utils/drm_utils.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\include/rga.h:
