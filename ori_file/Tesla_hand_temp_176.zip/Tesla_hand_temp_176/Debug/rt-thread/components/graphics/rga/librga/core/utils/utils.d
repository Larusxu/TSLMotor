rt-thread/components/graphics/rga/librga/core/utils/utils.o: \
 ../rt-thread/components/graphics/rga/librga/core/utils/utils.c \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\include/rga.h \
 ../rt-thread/components/graphics/rga/librga/core/utils/utils.h \
 ../rt-thread/components/graphics/rga/librga/core/utils/android_utils/android_utils.h \
 ../rt-thread/components/graphics/rga/librga/core/utils/drm_utils/drm_utils.h
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\include/rga.h:
../rt-thread/components/graphics/rga/librga/core/utils/utils.h:
../rt-thread/components/graphics/rga/librga/core/utils/android_utils/android_utils.h:
../rt-thread/components/graphics/rga/librga/core/utils/drm_utils/drm_utils.h:
