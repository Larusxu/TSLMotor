rt-thread/components/graphics/rga/librga/core/rga_sync.o: \
 ../rt-thread/components/graphics/rga/librga/core/rga_sync.c \
 ../rt-thread/components/graphics/rga/librga/core/rga_sync.h
../rt-thread/components/graphics/rga/librga/core/rga_sync.h:
