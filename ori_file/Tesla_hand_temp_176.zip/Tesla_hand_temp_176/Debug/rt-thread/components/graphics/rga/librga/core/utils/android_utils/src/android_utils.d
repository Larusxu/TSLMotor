rt-thread/components/graphics/rga/librga/core/utils/android_utils/src/android_utils.o: \
 ../rt-thread/components/graphics/rga/librga/core/utils/android_utils/src/android_utils.c \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\core\utils/android_utils/android_utils.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\include/rga.h
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\core\utils/android_utils/android_utils.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\include/rga.h:
