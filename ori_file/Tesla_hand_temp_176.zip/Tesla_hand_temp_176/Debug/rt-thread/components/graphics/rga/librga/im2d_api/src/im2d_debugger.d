rt-thread/components/graphics/rga/librga/im2d_api/src/im2d_debugger.o: \
 ../rt-thread/components/graphics/rga/librga/im2d_api/src/im2d_debugger.c \
 ../rt-thread/components/graphics/rga/librga/im2d_api/src/im2d_debugger.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\im2d_api/im2d_type.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\include/rga.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\im2d_api/im2d_version.h \
 ../rt-thread/components/graphics/rga/librga/im2d_api/src/im2d_impl.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\core\hardware/rga_ioctl.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\core\hardware/rga2_driver.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\include/drmrga.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\include/rga.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\im2d_api/im2d.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\im2d_api/im2d_type.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\im2d_api/im2d_common.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\im2d_api/im2d_buffer.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\im2d_api/im2d_single.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\im2d_api/im2d_task.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\im2d_api/im2d_mpi.h \
 ../rt-thread/components/graphics/rga/librga/im2d_api/src/im2d_hardware.h \
 ../rt-thread/components/graphics/rga/librga/im2d_api/src/im2d_log.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\compilers\common\include/unistd.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\compilers\common\include/sys/unistd.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/kpi.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rttypes.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176/rtconfig.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include\kconfig\rk3506/kconfig.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtthread.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtdef.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtsched.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rttypes.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtcompiler.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kerrno.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtservice.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtm.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtatomic.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rthw.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtklibc.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kstring.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kstdio.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kerrno.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\finsh/finsh.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\finsh/finsh_service.h \
 G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\include/RgaUtils.h
../rt-thread/components/graphics/rga/librga/im2d_api/src/im2d_debugger.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\im2d_api/im2d_type.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\include/rga.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\im2d_api/im2d_version.h:
../rt-thread/components/graphics/rga/librga/im2d_api/src/im2d_impl.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\core\hardware/rga_ioctl.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\core\hardware/rga2_driver.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\include/drmrga.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\include/rga.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\im2d_api/im2d.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\im2d_api/im2d_type.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\im2d_api/im2d_common.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\im2d_api/im2d_buffer.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\im2d_api/im2d_single.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\im2d_api/im2d_task.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\im2d_api/im2d_mpi.h:
../rt-thread/components/graphics/rga/librga/im2d_api/src/im2d_hardware.h:
../rt-thread/components/graphics/rga/librga/im2d_api/src/im2d_log.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\compilers\common\include/unistd.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\libs\libc\compilers\common\include/sys/unistd.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/kpi.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rttypes.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176/rtconfig.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include\kconfig\rk3506/kconfig.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtthread.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtdef.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtsched.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rttypes.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtcompiler.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kerrno.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtservice.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtm.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtatomic.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rthw.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/rtklibc.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kstring.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kstdio.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\include/klibc/kerrno.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\finsh/finsh.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\debug\finsh/finsh_service.h:
G:\project\hand\Tesla_hand\Tesla_hand_temp_176\rt-thread\components\graphics\rga\librga\include/RgaUtils.h:
