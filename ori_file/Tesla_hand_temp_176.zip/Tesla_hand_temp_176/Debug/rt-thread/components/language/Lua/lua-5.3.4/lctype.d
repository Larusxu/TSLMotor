rt-thread/components/language/Lua/lua-5.3.4/lctype.o: \
 ../rt-thread/components/language/Lua/lua-5.3.4/lctype.c \
 ../rt-thread/components/language/Lua/lua-5.3.4/lprefix.h \
 ../rt-thread/components/language/Lua/lua-5.3.4/lctype.h \
 ../rt-thread/components/language/Lua/lua-5.3.4/lua.h \
 ../rt-thread/components/language/Lua/lua-5.3.4/luaconf.h \
 ../rt-thread/components/language/Lua/lua-5.3.4/llimits.h
../rt-thread/components/language/Lua/lua-5.3.4/lprefix.h:
../rt-thread/components/language/Lua/lua-5.3.4/lctype.h:
../rt-thread/components/language/Lua/lua-5.3.4/lua.h:
../rt-thread/components/language/Lua/lua-5.3.4/luaconf.h:
../rt-thread/components/language/Lua/lua-5.3.4/llimits.h:
