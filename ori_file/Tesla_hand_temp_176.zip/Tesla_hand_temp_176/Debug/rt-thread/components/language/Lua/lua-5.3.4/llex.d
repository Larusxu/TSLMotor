rt-thread/components/language/Lua/lua-5.3.4/llex.o: \
 ../rt-thread/components/language/Lua/lua-5.3.4/llex.c \
 ../rt-thread/components/language/Lua/lua-5.3.4/lprefix.h \
 ../rt-thread/components/language/Lua/lua-5.3.4/lua.h \
 ../rt-thread/components/language/Lua/lua-5.3.4/luaconf.h \
 ../rt-thread/components/language/Lua/lua-5.3.4/lctype.h \
 ../rt-thread/components/language/Lua/lua-5.3.4/llimits.h \
 ../rt-thread/components/language/Lua/lua-5.3.4/ldebug.h \
 ../rt-thread/components/language/Lua/lua-5.3.4/lstate.h \
 ../rt-thread/components/language/Lua/lua-5.3.4/lobject.h \
 ../rt-thread/components/language/Lua/lua-5.3.4/ltm.h \
 ../rt-thread/components/language/Lua/lua-5.3.4/lzio.h \
 ../rt-thread/components/language/Lua/lua-5.3.4/lmem.h \
 ../rt-thread/components/language/Lua/lua-5.3.4/ldo.h \
 ../rt-thread/components/language/Lua/lua-5.3.4/lgc.h \
 ../rt-thread/components/language/Lua/lua-5.3.4/llex.h \
 ../rt-thread/components/language/Lua/lua-5.3.4/lparser.h \
 ../rt-thread/components/language/Lua/lua-5.3.4/lstring.h \
 ../rt-thread/components/language/Lua/lua-5.3.4/ltable.h
../rt-thread/components/language/Lua/lua-5.3.4/lprefix.h:
../rt-thread/components/language/Lua/lua-5.3.4/lua.h:
../rt-thread/components/language/Lua/lua-5.3.4/luaconf.h:
../rt-thread/components/language/Lua/lua-5.3.4/lctype.h:
../rt-thread/components/language/Lua/lua-5.3.4/llimits.h:
../rt-thread/components/language/Lua/lua-5.3.4/ldebug.h:
../rt-thread/components/language/Lua/lua-5.3.4/lstate.h:
../rt-thread/components/language/Lua/lua-5.3.4/lobject.h:
../rt-thread/components/language/Lua/lua-5.3.4/ltm.h:
../rt-thread/components/language/Lua/lua-5.3.4/lzio.h:
../rt-thread/components/language/Lua/lua-5.3.4/lmem.h:
../rt-thread/components/language/Lua/lua-5.3.4/ldo.h:
../rt-thread/components/language/Lua/lua-5.3.4/lgc.h:
../rt-thread/components/language/Lua/lua-5.3.4/llex.h:
../rt-thread/components/language/Lua/lua-5.3.4/lparser.h:
../rt-thread/components/language/Lua/lua-5.3.4/lstring.h:
../rt-thread/components/language/Lua/lua-5.3.4/ltable.h:
