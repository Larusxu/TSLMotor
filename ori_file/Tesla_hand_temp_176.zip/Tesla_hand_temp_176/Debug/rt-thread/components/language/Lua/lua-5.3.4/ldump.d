rt-thread/components/language/Lua/lua-5.3.4/ldump.o: \
 ../rt-thread/components/language/Lua/lua-5.3.4/ldump.c \
 ../rt-thread/components/language/Lua/lua-5.3.4/lprefix.h \
 ../rt-thread/components/language/Lua/lua-5.3.4/lua.h \
 ../rt-thread/components/language/Lua/lua-5.3.4/luaconf.h \
 ../rt-thread/components/language/Lua/lua-5.3.4/lobject.h \
 ../rt-thread/components/language/Lua/lua-5.3.4/llimits.h \
 ../rt-thread/components/language/Lua/lua-5.3.4/lstate.h \
 ../rt-thread/components/language/Lua/lua-5.3.4/ltm.h \
 ../rt-thread/components/language/Lua/lua-5.3.4/lzio.h \
 ../rt-thread/components/language/Lua/lua-5.3.4/lmem.h \
 ../rt-thread/components/language/Lua/lua-5.3.4/lundump.h
../rt-thread/components/language/Lua/lua-5.3.4/lprefix.h:
../rt-thread/components/language/Lua/lua-5.3.4/lua.h:
../rt-thread/components/language/Lua/lua-5.3.4/luaconf.h:
../rt-thread/components/language/Lua/lua-5.3.4/lobject.h:
../rt-thread/components/language/Lua/lua-5.3.4/llimits.h:
../rt-thread/components/language/Lua/lua-5.3.4/lstate.h:
../rt-thread/components/language/Lua/lua-5.3.4/ltm.h:
../rt-thread/components/language/Lua/lua-5.3.4/lzio.h:
../rt-thread/components/language/Lua/lua-5.3.4/lmem.h:
../rt-thread/components/language/Lua/lua-5.3.4/lundump.h:
